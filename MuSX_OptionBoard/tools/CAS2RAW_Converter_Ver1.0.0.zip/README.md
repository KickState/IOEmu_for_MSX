# CAS2RAW Converter Ver.1.0.0

CAS2RAW Converter is a Windows application that converts CAS images into uncompressed `.casraw` files using 1-bit DIGITAL RAW Sampling. It generates a deterministic cassette signal from the CAS content and the baud rate selected by the user.

This is a free DIY hobby project.

## AI-developed project

This software was developed, tested, and documented primarily by ChatGPT and Codex.

In contrast, the hardware and firmware for IOEμ are created entirely by hand.

日本語版: [README_ja.md](README_ja.md)

## Requirements

- Windows x64 PC
- A supported CAS image
- A writable output folder with enough free space

Python is not required for normal use. The application is distributed as a single executable. No cassette equipment, serial connection, or companion application is required for conversion.

If Windows reports a Microsoft Visual C++ runtime error, install the latest supported Microsoft Visual C++ Redistributable for x64 from Microsoft.

- [Microsoft documentation and x64 download](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170)

## Starting the application

Extract the complete release ZIP to a folder and start `CAS2RAW Converter.exe`.

## Basic workflow

1. Select **Choose CAS...** and open a CAS image.
2. Check the read-only SECTION table.
3. Select **1200** or **2400** under **Baud Rate:** for the intended target software/system.
4. Select **Single RAW** or **Split by FILE**.
5. Select **Convert...**. For Single RAW, choose a new `.casraw` filename. For Split by FILE, choose an output folder.
6. Wait for the status message and check the saved output.

Single RAW and 1200 are selected initially. These defaults do not indicate detection of the input's original baud rate.

## CAS selection and SECTION display

A SECTION is a marker-delimited unit in the CAS container and is not necessarily a complete logical file. The table shows each SECTION number, payload offset in hexadecimal, and payload byte count.

The table is for inspection only. Selecting a row does not limit the conversion range. Both output modes include every SECTION exactly once and in the original order, preserving all payload bytes.

Conversion uses the CAS content loaded when the file was selected. If the source file is changed by another application, select it again to load the new content.

## Baud rate

CAS images do not contain the original recording baud rate. Select 1200 or 2400 explicitly. The selection changes the generated signal timing, not the sample rate; both modes use 38,400 samples per second.

2400 generation is supported, but compatibility depends on the target software, loader, and system. It does not guarantee that every title will operate at 2400 baud.

## Output modes

### Single RAW

Writes all SECTIONs, in their original order, into one `.casraw` file. The suggested filename is `<stem>_<baud>.casraw`; another unused filename may be selected.

### Split by FILE

Writes one `.casraw` file for each positional FILE group. Normally, two consecutive SECTIONs are grouped into one FILE. If the SECTION count is odd and greater than one, the final unpaired SECTION is included in the last FILE, making that group contain three SECTIONs. A single SECTION produces one FILE.

For example, five SECTIONs are grouped as 1–2 and 3–5. This is the CAS2RAW Converter positional grouping rule, not universal MSX logical-file recognition. It does not inspect internal headers, data types, or EOF markers to determine grouping.

Files are named in order as `<stem>_F001_<baud>.casraw`, `<stem>_F002_<baud>.casraw`, and so on. `<stem>` is the input filename without its extension, and `<baud>` is 1200 or 2400.

## Output format and limits

The output is uncompressed `.casraw` in the `CASSMP01` format: a 48-byte header followed by packed 1-bit DIGITAL RAW Sampling data at 38,400 samples per second, one bit per sample, LSB-first within each byte. ZIP and audio-file output are not provided.

CAS2RAW Converter does not recover the original analog recording or waveform. CAS does not preserve the original edge timing, phase, distortion, or exact gap lengths. The converter synthesizes signal timing deterministically from the preserved CAS payloads and the selected baud rate.

Supported inputs use marker-delimited CAS SECTIONs with a nonempty payload in every SECTION. The application does not repair malformed images. If the CAS marker byte sequence occurs inside payload data, the representation is ambiguous and unsupported.

## Release-package contents

```text
CAS2RAW Converter.exe
README.md
README_ja.md
LICENSE
THIRD_PARTY_NOTICES.txt
```

## Notes

- This is a DIY hobby project; use it at your own risk.
- Keep the original CAS image. Loading and converting do not modify the input file.
- Existing output files are not overwritten. If a Split by FILE save fails after some files have already been saved, those files may remain; check the status message before retrying.
- Wait for conversion to finish before closing the application.
- CAS2RAW Converter creates files only; it does not capture or play cassette signals. Successful conversion does not guarantee compatibility with every target software/system or every Windows environment.
