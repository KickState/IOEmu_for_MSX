# μSX CAS-IF Signal Analyzer Ver.1.0.0

μSX CAS-IF Signal Analyzer is a Windows application for visualizing and analyzing cassette signals recorded using 1-bit DIGITAL RAW Sampling. It opens `.casraw` and `.casraw.zip` files, displays the stored signal waveform, decodes cassette data, and can save the decoded result as Binary or CAS data.

This is a free DIY hobby project.

## AI-developed project

This software was developed, tested, and documented primarily by ChatGPT and Codex.

In contrast, the hardware and firmware for IOEμ are created entirely by hand.

日本語版: [README_ja.md](README_ja.md)

## Requirements

- Windows x64 PC
- A supported `.casraw` or `.casraw.zip` input file

Python is not required for normal use. The application is distributed as a single executable.

If Windows reports a Microsoft Visual C++ runtime error, install the latest supported Microsoft Visual C++ Redistributable for x64 from Microsoft.

- [Microsoft documentation and x64 download](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170)

## Starting the application

Extract the complete release ZIP to a folder. Start `μSX CAS-IF Signal Analyzer.exe`, then use **Open…** to select a `.casraw` or `.casraw.zip` file.

A supported input file may also be supplied as a command-line argument when starting the application.

## Basic workflow

1. Open a `.casraw` or `.casraw.zip` file.
2. Inspect the waveform, using zoom controls and Cursor A/B to examine signal timing.
3. Run **DUMP** to decode the cassette data and populate Physical Overview.
4. Use Physical Overview to navigate the recording's overall signal structure.
5. Select a byte in DUMP to compare it with the corresponding waveform observations.
6. Use **Save Binary…** or **Save CAS…** when you want to save the decoded result.

## Analyzer functions

### Waveform display

The Analyzer displays the signal waveform stored by 1-bit DIGITAL RAW Sampling in the detail view, with an overview for navigating the recording.

You can navigate with the overview, zoom with the mouse wheel or GUI controls, and place Cursor A/B to measure Δt and frequency.

### Physical Overview

After DUMP, Physical Overview helps you inspect the large-scale structure of the recorded cassette signal separately from the decoded byte data.

It is an aid for signal inspection; it does not define or rewrite the logical contents exported by DUMP or Save CAS.

### DUMP

**DUMP** runs the decoder and displays the recovered logical byte stream with byte offsets, hexadecimal values, and ASCII characters.

It does not simply list the packed bits stored in the input file.

Selecting a byte in DUMP synchronizes the waveform view with the signal observations used to decode that byte. This makes it possible to compare decoded data with its source waveform. Cursor A/B marks these observations, not exact boundaries in the transmitted signal.

A waveform can exist even when a valid byte cannot be decoded from it.

### Save Binary

After DUMP has produced decoded data, **Save Binary…** saves the displayed byte stream as a binary file.

This is the decoder output itself. It is useful for inspection and comparison, but it is not necessarily a file that an MSX can load directly.

### Save CAS

When the decoded result can be represented as a CAS image, **Save CAS…** becomes available after DUMP. It saves that decoded logical data without decoding the signal again.

This is a decoded-data export, not a lossless conversion of the original recording. A CAS image does not preserve the original edge timing, phase, signal distortion, or exact gap lengths.

Keep the original `.casraw` or `.casraw.zip` file as the signal-level master.

## Supported input formats

The Analyzer accepts files recorded using 1-bit DIGITAL RAW Sampling at 38,400 or 76,800 samples per second.

### `.casraw`

An uncompressed file containing the recorded 1-bit DIGITAL RAW Sampling data.

### `.casraw.zip`

An unencrypted ZIP (Deflate) file containing exactly one `.casraw` file and no other entries.

## Release-package contents

```text
μSX CAS-IF Signal Analyzer.exe
README.md
README_ja.md
LICENSE
THIRD_PARTY_NOTICES.txt
```

## Notes

- This is a DIY hobby project; use it at your own risk.
- Opening and analyzing an input file does not modify it. Save exports to a different file so that the original is retained.
- The Analyzer analyzes existing signal files; it does not capture or play cassette signals.
