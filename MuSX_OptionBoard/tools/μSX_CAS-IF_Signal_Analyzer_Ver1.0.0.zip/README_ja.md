# μSX CAS-IF Signal Analyzer Ver.1.0.0

μSX CAS-IF Signal Analyzer は、1-bit DIGITAL RAW Sampling で記録したカセット信号を可視化・解析する Windows アプリケーションです。`.casraw` / `.casraw.zip` を開き、保存された信号波形の確認、カセットデータのデコード、Binary / CAS 形式でのデコード結果保存を行えます。

本ソフトウェアは、無償公開の DIY 趣味プロジェクトです。

## AIによる開発について

本ソフトウェアは、ChatGPT と Codex を主体として開発・検証・文書作成を行ったAI開発成果物です。

一方、IOEμのハードウェアとfirmwareは、人力100%で作成されています。

English version: [README.md](README.md)

## 動作環境

- Windows x64 PC
- 対応する `.casraw` または `.casraw.zip` 入力ファイル

通常利用に Python は不要です。本アプリケーションは単一の実行ファイルとして配布されます。

Windows が Microsoft Visual C++ Runtime に関するエラーを表示する場合は、Microsoft公式の最新対応 Visual C++ Redistributable x64 を導入してください。

- [Microsoft公式案内・x64版ダウンロード](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170)

## 起動方法

リリース ZIP 全体をフォルダへ展開します。`μSX CAS-IF Signal Analyzer.exe` を起動し、**Open…** から `.casraw` または `.casraw.zip` を選択します。

起動時にコマンドライン引数として対応入力ファイルを指定することもできます。

## 基本的な使い方

1. `.casraw` または `.casraw.zip` を開きます。
2. 波形を確認し、ズームと Cursor A/B を使って信号タイミングを調べます。
3. **DUMP** を実行してカセットデータをデコードし、Physical Overview を表示します。
4. Physical Overview で記録全体の信号構造を確認し、表示位置を移動します。
5. DUMP 内のバイトを選択し、対応する波形の観測位置と比較します。
6. 必要に応じて **Save Binary…** または **Save CAS…** でデコード結果を保存します。

## Analyzer の機能

### 波形表示

1-bit DIGITAL RAW Sampling で保存された信号波形を詳細ビューに表示し、全体表示で記録内の位置を確認できます。

全体ビューによる表示位置の移動、マウスホイールまたは GUI 操作による拡大・縮小、Cursor A/B による Δt と周波数の確認ができます。

### Physical Overview

Physical Overview は DUMP 実行後に表示され、記録されたカセット信号の大きな構造を、デコードされたバイト列とは別に確認するための表示です。

信号確認のための補助表示であり、DUMP や Save CAS が扱う論理データを決定・変更するものではありません。

### DUMP

**DUMP** はデコーダーを実行し、復元した論理バイト列をバイト位置（オフセット）、16進数値、ASCII 表示で確認する機能です。

入力ファイルに格納されたビット列をそのまま並べる機能ではありません。

DUMP 内のバイトを選択すると、そのバイトのデコードに使われた信号観測位置へ波形表示が連動します。これにより、デコード結果と元の信号を比較できます。Cursor A/B はこの観測位置を示し、送信信号の厳密な境界を示すものではありません。

波形が存在していても、有効なバイトとしてデコードできない場合があります。

### Save Binary

DUMP でデコード済みデータが得られた後、**Save Binary…** で表示中のバイト列を Binary ファイルとして保存できます。

これはデコーダーが出力したバイト列そのものです。解析や比較には利用できますが、必ずしも MSX が直接読み込めるファイル形式とは限りません。

### Save CAS

DUMP の結果を CAS イメージとして表現できる場合に、**Save CAS…** が使用可能になります。信号を再デコードせず、得られた論理データを保存します。

これはデコード結果の保存であり、元の録音を完全に複製する変換ではありません。元の信号のエッジタイミング、位相、波形の乱れ、無信号区間の正確な長さは CAS イメージには保持されません。

信号レベルの原本として、元の `.casraw` または `.casraw.zip` を残してください。

## 対応入力形式

1-bit DIGITAL RAW Sampling で記録した、38,400 または 76,800 samples/sec のファイルに対応します。

### `.casraw`

記録された 1-bit DIGITAL RAW Sampling データを格納する非圧縮ファイルです。

### `.casraw.zip`

暗号化されていない ZIP（Deflate）で、`.casraw` を1件だけ格納し、ほかのエントリを含めない形式です。

## リリースパッケージ内容

```text
μSX CAS-IF Signal Analyzer.exe
README.md
README_ja.md
LICENSE
THIRD_PARTY_NOTICES.txt
```

## 注意事項

- DIY 趣味プロジェクトです。自己責任で利用してください。
- 入力ファイルの読み込み・解析では元のファイルを変更しません。原本を残すため、出力の保存先には別のファイルを指定してください。
- Analyzer は保存済み信号を解析するツールであり、カセット信号の取り込みや再生は行いません。
