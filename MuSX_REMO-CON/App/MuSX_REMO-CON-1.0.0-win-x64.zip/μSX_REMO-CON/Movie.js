/* Browser movie lifecycle. Records only the stream supplied by the live preview. */
(function (global) {
  'use strict';
  const PIECE = 256 * 1024, QUEUE = 16 * 1024 * 1024, TOTAL = 512 * 1024 * 1024;
  const CANDIDATES = ['video/mp4;codecs=avc1.42E01E,mp4a.40.2',
    'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
  class RemoconMovie {
    constructor(ui) {
      this.ui = ui; this.state = 'Ready'; this.op = null; this.review = null;
      this.latest = null; this.message = ''; this.exiting = false; this.revision = 0;
      this.update();
    }
    isReview() { return ['ReviewLoading','Reviewing','ReviewClosing'].includes(this.state); }
    live() {
      const s = this.ui.getStream();
      return s && s.getVideoTracks().some(t => t.readyState === 'live') &&
        s.getAudioTracks().some(t => t.readyState === 'live');
    }
    url(action, id, sequence) {
      return this.ui.origin + '/movie/' + this.ui.token + '/' + action +
        (id ? '/' + id : '') + (sequence === undefined ? '' : '/' + sequence);
    }
    active(op) { return !this.exiting && this.op === op && !op.failed; }
    update() {
      const u = this.ui, busy = this.exiting || this.state !== 'Ready';
      const monitorBlocked = !!(u.canUseMovie && !u.canUseMovie());
      u.record.disabled = busy || !this.live() || monitorBlocked;
      u.play.disabled = busy || !this.latest || monitorBlocked;
      u.stop.disabled = this.exiting || !['Starting','Recording','ReviewLoading','Reviewing','ReviewClosing'].includes(this.state);
      u.audioButton.disabled = this.exiting || this.isReview() || !u.getStream();
      u.volume.disabled = this.exiting || this.isReview() || !u.getStream();
      if (this.exiting) u.label.textContent = 'Movie inactive — page closed';
      else if (this.state === 'Recording') {
        const seconds = Math.floor((performance.now() - this.op.started) / 1000);
        u.label.textContent = 'REC ' + String(Math.floor(seconds / 60)).padStart(2,'0') + ':' +
          String(seconds % 60).padStart(2,'0') + ' / 05:00';
      } else if (this.state === 'Starting') u.label.textContent = 'starting…';
      else if (this.state === 'Finalizing') u.label.textContent = 'finalizing…';
      else if (this.isReview()) u.label.textContent = this.message || (this.state==='ReviewLoading' ? 'loading…' : this.state==='ReviewClosing' ? 'stopping…' : 'playback');
      else if (monitorBlocked) u.label.textContent = u.movieBlockedMessage || 'Movie is unavailable for the selected monitor route.';
      else u.label.textContent = this.message || (this.live() || this.latest ? 'ready' : 'Start LIVE to record');
      if (u.monitorUpdate) u.monitorUpdate(this);
    }
    async request(action, id, body, op, sequence) {
      const controller = new AbortController();
      if (op) op.requests.add(controller);
      const timer = setTimeout(() => controller.abort(), 8000);
      try {
        const read = ['latest','status'].includes(action);
        const response = await fetch(this.url(action,id,sequence), {
          method: read ? 'GET' : 'POST',
          mode: 'cors', cache: 'no-store', signal: controller.signal,
          headers: body ? {'Content-Type': body instanceof Blob ? 'application/octet-stream' : 'application/json'} : {},
          body: body ? (body instanceof Blob ? body : JSON.stringify(body)) : undefined
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || 'Movie request failed.');
        return data;
      } finally {
        clearTimeout(timer); if (op) op.requests.delete(controller);
      }
    }
    async refresh() {
      const revision=this.revision;
      try {
        const result=await this.request('latest');
        if(revision===this.revision && !this.exiting) this.latest=result.movie;
      } catch (e) {
        if(revision===this.revision && !this.exiting) this.message = 'Movie service unavailable.';
      }
      if (revision===this.revision && !this.exiting) this.update();
    }
    clearTimers(op) { for (const t of op.timers) { clearTimeout(t); clearInterval(t); } op.timers.clear(); }
    timer(op, fn, ms, interval = false) {
      const callback = () => { if (this.active(op)) fn(); };
      const id = interval ? setInterval(callback,ms) : setTimeout(callback,ms);
      op.timers.add(id); return id;
    }
    stopRecorder(op) {
      if (op.stopIssued) return;
      op.stopIssued = true;
      if (op.recorder && op.recorder.state !== 'inactive') op.recorder.stop();
    }
    clean(op) {
      this.clearTimers(op);
      for (const controller of op.requests) controller.abort();
      op.requests.clear(); op.queue.length = 0; op.queued = 0;
      if (op.probe) { op.probe.pause(); op.probe.removeAttribute('src'); op.probe.load(); op.probe = null; }
      for (const track of op.tracks || []) track.removeEventListener('ended',op.onTrackEnd);
    }
    fail(op, error, cancel = true) {
      if (this.op !== op || op.failed) return;
      op.failed = true;
      try { this.stopRecorder(op); } catch {}
      this.clean(op);
      if (cancel) this.request('cancel',op.id).catch(() => {});
      this.op = null; this.state = 'Ready';
      this.message = error.message || String(error);
      if (!this.exiting) this.update();
    }
    async start() {
      if (this.ui.canUseMovie && !this.ui.canUseMovie()) {
        this.message = this.ui.movieBlockedMessage || 'Movie is unavailable for the selected monitor route.';
        this.update();
        return;
      }
      if (this.state !== 'Ready' || !this.live() || this.exiting) return;
      // This guard changes synchronously, before format selection or any request.
      this.state = 'Starting';
      this.revision++;
      const op = {id: crypto.randomUUID().replace(/-/g,''), queue: [], queued: 0, received: 0,
        bytes: 0, pieces: 0, requests: new Set(), timers: new Set(), failed: false,
        draining: false, ended: false, finishing: false, stopIssued: false, recorder: null};
      this.op = op; this.message = ''; this.update();
      this.timer(op,() => this.fail(op,new Error('Movie start timed out.')),10000);
      try {
        if (!global.MediaRecorder) throw new Error('Movie recording is unavailable in this browser.');
        op.requested = CANDIDATES.find(mime => global.MediaRecorder.isTypeSupported(mime));
        if (!op.requested) throw new Error('No supported movie format.');
        const source = this.ui.getStream();
        op.recorder = new global.MediaRecorder(source, {mimeType: op.requested, videoBitsPerSecond: 4000000, audioBitsPerSecond: 128000});
        op.tracks = source.getTracks();
        op.onTrackEnd = () => this.fail(op,new Error('Live capture ended; movie was not committed.'));
        for (const track of op.tracks) track.addEventListener('ended',op.onTrackEnd);
        op.recorder.addEventListener('dataavailable', e => this.receive(op,e.data));
        op.recorder.addEventListener('error', e => this.fail(op,e.error || new Error('Movie recorder failed.')));
        op.recorder.addEventListener('start', () => {
          if (!this.active(op)) return;
          this.clearTimers(op); op.started = performance.now(); op.lastTick = op.started;
          this.state = 'Recording'; this.update();
          this.timer(op,() => {
            const now = performance.now();
            if (now-op.lastTick > 10000) { this.fail(op,new Error('Movie interrupted while the browser was suspended.')); return; }
            op.lastTick = now;
            if (now-op.started >= 300000) this.stop();
            else this.update();
          },500,true);
          this.timer(op,() => this.stop(),300000);
          this.timer(op,() => {
            if (!op.heartbeat) {
              op.heartbeat = true;
              this.request('heartbeat',op.id,null,op).catch(e => {
                if(this.state==='Recording') this.fail(op,e);
              }).finally(() => { op.heartbeat=false; });
            }
          },10000,true);
        });
        op.recorder.addEventListener('stop', () => {
          if (!this.active(op) || op.ended) return;
          if (!op.stopIssued) { this.fail(op,new Error('Movie ended unexpectedly.')); return; }
          op.ended = true;
          // MediaRecorder delivers its final dataavailable before this event.
          this.finish(op);
        });
        await this.request('start',op.id,{requestedMime:op.requested},op);
        if (!this.active(op)) { this.request('cancel',op.id).catch(() => {}); return; }
        op.recorder.start(1000);
      } catch(e) { this.fail(op,e); }
    }
    receive(op, blob) {
      if (!this.active(op) || !blob || !blob.size || op.ended) return;
      if (op.queued + blob.size > QUEUE || op.received + blob.size > TOTAL) {
        this.fail(op,new Error('Movie safety buffer limit exceeded; incomplete movie discarded.')); return;
      }
      op.received += blob.size; op.queued += blob.size;
      op.queue.push(blob); this.drain(op);
      // Leave headroom for the recorder's final event.
      if (op.queued >= QUEUE * .75 || op.received >= TOTAL - QUEUE) this.stop();
    }
    async drain(op) {
      if (!this.active(op) || op.draining) return;
      op.draining = true;
      try {
        while (op.queue.length && this.active(op)) {
          const blob = op.queue[0];
          for (let offset=0; offset<blob.size && this.active(op); offset+=PIECE) {
            const piece = blob.slice(offset,Math.min(offset+PIECE,blob.size));
            const reply = await this.request('chunk',op.id,piece,op,op.pieces);
            if (!this.active(op)) return;
            if (reply.sequence !== op.pieces+1 || reply.bytes !== op.bytes+piece.size)
              throw new Error('Movie upload acknowledgement mismatch.');
            op.pieces++; op.bytes += piece.size;
          }
          // Count the entire Blob until its last piece is acknowledged.
          op.queued -= blob.size; op.queue.shift();
        }
      } catch(e) { this.fail(op,e); }
      finally { op.draining=false; if (this.active(op) && op.ended) this.finish(op); }
    }
    stop() {
      if (this.isReview()) { this.stopReview(); return; }
      const op=this.op;
      if (!op || !this.active(op)) return;
      if (this.state === 'Starting') { this.fail(op,new Error('Movie start cancelled.')); return; }
      if (this.state !== 'Recording') return;
      this.state='Finalizing'; this.clearTimers(op); this.update();
      this.timer(op,() => this.fail(op,new Error('Movie finalization timed out.')),45000);
      try { this.stopRecorder(op); } catch(e) { this.fail(op,e); }
    }
    async validateMedia(op) {
      const video=document.createElement('video');
      op.probe=video; video.muted=true; video.preload='auto'; video.crossOrigin='anonymous';
      await new Promise((resolve,reject) => {
        let done=false, decoded=false, sought=false;
        const timer=setTimeout(() => end(new Error('Movie decode/seek validation timed out.')),12000);
        const end=error => {
          if(done) return; done=true; clearTimeout(timer);
          video.onloadeddata=video.onseeked=video.onerror=video.ondurationchange=null;
          error?reject(error):resolve();
        };
        video.onerror=() => end(new Error('Recorded movie could not be decoded.'));
        video.onseeked=() => { sought=true; if(decoded) end(); };
        video.onloadeddata=() => {
          decoded=video.videoWidth>0 && video.videoHeight>0;
          if(!decoded) { end(new Error('Movie contains no decodable video.')); return; }
          // WebM may omit duration; seek into the known recording span instead.
          const seconds=Math.max(.05,(performance.now()-op.started)/1000);
          video.currentTime=Number.isFinite(video.duration)&&video.duration>0 ?
            Math.min(video.duration*.5,seconds*.5) : Math.min(.25,seconds*.5);
          if(sought) end();
        };
        video.src=this.url('preview',op.id); video.load();
      });
      video.pause(); video.removeAttribute('src'); video.load(); op.probe=null;
    }
    async finish(op) {
      if (!this.active(op) || !op.ended || op.draining || op.queue.length || op.finishing) return;
      op.finishing=true;
      try {
        if(op.bytes !== op.received || !op.bytes) throw new Error('Movie final byte count mismatch.');
        const recorderMime=op.recorder.mimeType;
        await this.request('prepare',op.id,{ended:true,bytes:op.bytes,pieces:op.pieces,recorderMime},op);
        if(!this.active(op)) return;
        await this.validateMedia(op);
        if(!this.active(op)) return;
        let result;
        try { result=await this.request('commit',op.id,{validated:true,bytes:op.bytes,pieces:op.pieces},op); }
        catch(e) {
          if(!this.active(op)) return;
          try {
            result=await this.request('status',op.id,null,op);
            if(result.state!=='committed') throw e;
          } catch {
            this.fail(op,new Error('Movie save unconfirmed; latest will be checked on next load.'),false); return;
          }
        }
        if(!this.active(op)) return;
        this.latest=result.movie; this.clean(op); this.op=null; this.state='Ready';
        this.message='Saved: '+result.movie.fileName; this.update();
      } catch(e) { this.fail(op,e); }
    }
    async play() {
      if (this.ui.canUseMovie && !this.ui.canUseMovie()) {
        this.message = this.ui.movieBlockedMessage || 'Movie is unavailable for the selected monitor route.';
        this.update();
        return;
      }
      if(this.state!=='Ready' || this.exiting) return;
      this.revision++;
      const u=this.ui, review={requests:new Set()};
      this.review=review; this.state='ReviewLoading'; this.message='';
      review.onEnded=() => { if(this.review===review) this.stopReview(); };
      review.onError=() => {
        if(this.review===review) { this.message='PLAYBACK could not continue.'; this.stopReview(); }
      };
      u.video.addEventListener('ended',review.onEnded);
      u.video.addEventListener('error',review.onError);
      review.monitor=u.monitorState ? u.monitorState() : {paused:u.audio.paused,muted:u.audio.muted,volume:u.audio.volume};
      u.audio.pause(); u.badge.hidden=false; u.clearDrop(); this.update();
      review.timeout=setTimeout(() => {
        if(this.review===review) { this.message='PLAYBACK preparation timed out.'; this.stopReview(); }
      },u.preparePlaybackAudio ? 120000 : 12000);
      try {
        if(u.suspendLiveAudio)await u.suspendLiveAudio();
        if(this.review!==review)return;
        const result=await this.request('latest',null,null,review);
        if(this.review!==review) return;
        if(!result.movie) { this.latest=null; this.message='No completed movie yet.'; this.stopReview(); return; }
        review.id=result.movie.id; this.latest=result.movie;
        u.preview.hidden=true; u.video.hidden=false;
        if(u.preparePlaybackAudio) {u.video.muted=true;u.video.defaultMuted=true;}
        u.video.crossOrigin='anonymous'; u.video.src=this.url('file',review.id);
        if(u.preparePlaybackAudio)await u.preparePlaybackAudio(this.url('file',review.id),result.movie);
        if(this.review!==review)return;
        review.audioReady=true;
        await u.video.play();
        if(this.review!==review) return;
        clearTimeout(review.timeout); this.state='Reviewing'; u.video.focus(); this.update();
      } catch(e) {
        if(this.review===review) { this.message='PLAYBACK unavailable — '+e.message; this.stopReview(); }
      }
    }
    stopReview() {
      const review=this.review || this.closingReview; if(!review) return;
      if(review.closing)return review.closedPromise;
      review.closing=true; this.closingReview=review;
      this.review=null; clearTimeout(review.timeout);
      for(const request of review.requests) request.abort();
      const u=this.ui; u.video.pause(); u.video.removeAttribute('src'); u.video.load();
      u.video.removeEventListener('ended',review.onEnded);
      u.video.removeEventListener('error',review.onError);
      u.video.blur(); u.video.hidden=true; u.badge.hidden=true;
      u.preview.hidden=!u.getStream() || !u.getStream().getVideoTracks().some(t => t.readyState==='live');
      if(!u.stopPlaybackAudio){u.audio.muted=review.monitor.muted; u.audio.volume=review.monitor.volume;}
      const revision=this.revision;
      const finish=()=>{
      this.closingReview=null;this.state='Ready';
      if(!this.exiting && !review.monitor.paused && u.getStream() &&
          (!u.canRestoreMonitor || u.canRestoreMonitor()))
        (u.resumeLiveAudio ? u.resumeLiveAudio() : u.audio.play()).catch(() => {
          if(!this.exiting && revision===this.revision && this.state==='Ready') {
            this.message='Select Mute to resume live monitoring.'; this.update();
          }
        });
      if(!this.exiting) { u.focusLive(); this.update(); }
      };
      if(u.stopPlaybackAudio){
        this.state='ReviewClosing';this.update();
        review.closedPromise=u.stopPlaybackAudio(this.exiting).then(finish).catch(e=>{review.closing=false;this.message='PLAYBACK close failed — '+e.message;this.update();});
        return review.closedPromise;
      }else finish();
    }
    endPreview(exiting) {
      this.revision++;
      const permanentlyExiting=this.exiting || exiting;
      // Suppress live-audio restoration while the caller is stopping its source.
      this.exiting=true;
      if(this.review || this.closingReview) this.stopReview();
      const op=this.op;
      if(op) this.fail(op,new Error('Incomplete movie discarded when preview stopped.'));
      else this.message='';
      this.exiting=permanentlyExiting;
      this.update();
      if(!this.exiting) this.refresh();
      // Source-track teardown belongs exclusively to the caller's preview teardown.
    }
    previewStopped() { this.endPreview(false); }
    teardown() { this.endPreview(true); }
  }
  RemoconMovie.PIECE=PIECE; RemoconMovie.QUEUE=QUEUE; RemoconMovie.TOTAL=TOTAL;
  if(typeof module !== 'undefined' && module.exports) module.exports=RemoconMovie;
  else global.RemoconMovie=RemoconMovie;
})(typeof window === 'undefined' ? globalThis : window);
