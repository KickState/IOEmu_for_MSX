// Movie-only, in-process I/O worker. No capture APIs or child processes.
// Compatible with the Windows PowerShell 5.1 Add-Type compiler / .NET Framework.
using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Security.Cryptography;
using System.Web.Script.Serialization;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace Remocon {
// One monotonic cooperative budget is shared by every storage step of a request.
public sealed class MovieWork {
    readonly Stopwatch clock = Stopwatch.StartNew();
    readonly int milliseconds;
    readonly CancellationToken cancellation;
    readonly Func<bool> disconnected;
    long nextPeerCheck;
    public MovieWork(int milliseconds, CancellationToken cancellation, Func<bool> disconnected = null) {
        this.milliseconds=milliseconds; this.cancellation=cancellation; this.disconnected=disconnected;
    }
    public void Check() {
        cancellation.ThrowIfCancellationRequested();
        if(clock.ElapsedMilliseconds >= milliseconds) throw new OperationCanceledException("Movie storage deadline exceeded.");
        if(disconnected!=null && clock.ElapsedMilliseconds>=nextPeerCheck) {
            nextPeerCheck=clock.ElapsedMilliseconds+50;
            if(disconnected()) throw new OperationCanceledException("Movie caller disconnected.");
        }
    }
    internal static void Check(MovieWork work) { if(work!=null) work.Check(); }
    internal IDisposable Enter(object gate) {
        while(true) {
            Check();
            if(Monitor.TryEnter(gate,50)) {
                try { Check(); return new GateLease(gate); }
                catch { Monitor.Exit(gate); throw; }
            }
        }
    }
    sealed class GateLease : IDisposable {
        readonly object gate;
        public GateLease(object gate) { this.gate=gate; }
        public void Dispose() { Monitor.Exit(gate); }
    }
}
// Checks both sides of every bounded read/seek/property call. An in-flight OS call
// must return before cooperative cancellation can be observed; no detached I/O tasks.
sealed class MovieReadStream : Stream {
    readonly Stream inner; readonly MovieWork work;
    public MovieReadStream(Stream inner, MovieWork work) { this.inner=inner; this.work=work; work.Check(); }
    public override int Read(byte[] b,int offset,int count) {
        work.Check(); int n=inner.Read(b,offset,Math.Min(count,65536)); work.Check(); return n;
    }
    public override int ReadByte() { work.Check(); int n=inner.ReadByte(); work.Check(); return n; }
    public override long Seek(long offset,SeekOrigin origin) { work.Check(); long n=inner.Seek(offset,origin); work.Check(); return n; }
    public override long Length { get { work.Check(); long n=inner.Length; work.Check(); return n; } }
    public override long Position { get { work.Check(); return inner.Position; } set { work.Check(); inner.Position=value; work.Check(); } }
    public override bool CanRead { get { return true; } }
    public override bool CanSeek { get { return inner.CanSeek; } }
    public override bool CanWrite { get { return false; } }
    public override void Flush() { throw new NotSupportedException(); }
    public override void SetLength(long value) { throw new NotSupportedException(); }
    public override void Write(byte[] b,int offset,int count) { throw new NotSupportedException(); }
    // Caller owns the underlying stream, including disposal on cancellation.
}
public static class MovieStorage {
    public static string Hash(Stream input,MovieWork work) {
        var f=new MovieReadStream(input,work);
        using(var hash=SHA256.Create()) {
            byte[] buffer=new byte[65536]; int n;
            while((n=f.Read(buffer,0,buffer.Length))>0) {
                work.Check(); hash.TransformBlock(buffer,0,n,buffer,0); work.Check();
            }
            hash.TransformFinalBlock(buffer,0,0); work.Check();
            return BitConverter.ToString(hash.Hash).Replace("-","").ToLowerInvariant();
        }
    }
}
public sealed class MovieReceipt {
    public string id, fileName, completedUtc, requestedMime, recorderMime, container, sha256, validation;
    public string codecs; // Reported by recorder only; not inferred from extension.
    public long bytes;
    public int pieces;
}
sealed class MovieSession {
    public string Id, Partial, Requested, Reported, Extension, PreparedHash;
    public FileStream File;
    public long Bytes;
    public int Sequence;
    public DateTime Created = DateTime.UtcNow, Touched = DateTime.UtcNow;
    public string State = "uploading";
    public MovieReceipt Receipt;
}
sealed class MovieHttpError : Exception {
    public int Status;
    public MovieHttpError(int status, string message) : base(message) { Status = status; }
}
public sealed class MovieWorker : IDisposable {
    public Func<string,string,Dictionary<string,object>,byte[],object> AudioRequest;
    public static IDisposable BoundControlRead(TcpClient client) {
        return new Timer(_ => { try { client.Close(); } catch {} }, null, 5000, Timeout.Infinite);
    }
    [StructLayout(LayoutKind.Sequential)]
    struct FileIdentity {
        public uint Attributes, CreatedLow, CreatedHigh, AccessLow, AccessHigh, WrittenLow, WrittenHigh;
        public uint Volume, SizeHigh, SizeLow, Links, IndexHigh, IndexLow;
    }
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool GetFileInformationByHandle(Microsoft.Win32.SafeHandles.SafeFileHandle handle, out FileIdentity info);
    static void SingleLink(string path, MovieWork work = null) {
        MovieWork.Check(work);
        using(var f=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read)) {
            FileIdentity info;
            if(!GetFileInformationByHandle(f.SafeFileHandle,out info) || info.Links!=1)
                throw new IOException("Movie files must have a single owned link.");
            MovieWork.Check(work);
        }
    }
    public const int PieceLimit = 262144;
    public const long TotalLimit = 536870912;
    readonly string root, directory, origin, token;
    readonly object gate = new object(), clientsGate = new object();
    readonly Dictionary<string, MovieSession> sessions = new Dictionary<string, MovieSession>();
    readonly HashSet<TcpClient> clients = new HashSet<TcpClient>();
    readonly List<Thread> threads = new List<Thread>();
    readonly TcpListener listener;
    readonly Thread acceptThread;
    readonly Timer expiry;
    volatile bool disposed;
    readonly CancellationTokenSource stopping = new CancellationTokenSource();
    public string BaseUrl { get; private set; }
    public MovieWorker(string projectRoot, string pageOrigin, string hostToken) {
        root = Path.GetFullPath(projectRoot);
        directory = Path.Combine(root, "MOVIE_DATA");
        origin = pageOrigin; token = hostToken;
        CheckTree(root); Directory.CreateDirectory(directory); CheckTree(directory);
        // Only our exact temporary names are removed; never touch finalized/orphan media.
        foreach (string p in Directory.EnumerateFiles(directory, "*.partial").Take(32))
            if (Regex.IsMatch(Path.GetFileName(p), "^[a-f0-9]{32}\\.(media|receipt)\\.partial$")) {
                Safe(p);
                if (File.GetLastWriteTimeUtc(p) < DateTime.UtcNow.AddMinutes(-10)) File.Delete(p);
            }
        listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start(16);
        BaseUrl = "http://127.0.0.1:" + ((IPEndPoint)listener.LocalEndpoint).Port;
        acceptThread = new Thread(Accept) { IsBackground = true, Name = "Remocon movie accept" };
        acceptThread.Start();
        expiry = new Timer(Expire, null, 1000, 1000);
    }
    static void CheckTree(string path, MovieWork work = null) {
        MovieWork.Check(work);
        for (string p = Path.GetFullPath(path); !String.IsNullOrEmpty(p); p = Path.GetDirectoryName(p)) {
            MovieWork.Check(work);
            if ((File.Exists(p) || Directory.Exists(p)) && (File.GetAttributes(p) & FileAttributes.ReparsePoint) != 0)
                throw new IOException("Movie paths must not contain links or junctions.");
            MovieWork.Check(work);
        }
    }
    string Safe(string path, MovieWork work = null) {
        CheckTree(directory,work);
        string full = Path.GetFullPath(path);
        if (!String.Equals(Path.GetDirectoryName(full), directory, StringComparison.OrdinalIgnoreCase))
            throw new IOException("Movie path is outside its owned directory.");
        CheckTree(full,work);
        return full;
    }
    string Owned(string name, MovieWork work = null) { return Safe(Path.Combine(directory, name),work); }
    void Accept() {
        while (!disposed) {
            TcpClient c;
            try { c = listener.AcceptTcpClient(); } catch { break; }
            lock (clientsGate) {
                threads.RemoveAll(thread => !thread.IsAlive);
                if (disposed || clients.Count >= 8) { c.Close(); continue; }
                clients.Add(c);
                var t = new Thread(() => Serve(c)) { IsBackground = true, Name = "Remocon movie request" };
                threads.Add(t); t.Start();
            }
        }
    }
    static JavaScriptSerializer Json() { return new JavaScriptSerializer { MaxJsonLength = 16384 }; }
    static void Fail(bool condition, string message) { if (condition) throw new MovieHttpError(409, message); }
    void Headers(NetworkStream s, int status, string type, long length, string extra) {
        string text = "HTTP/1.1 " + status + " " + (status == 200 ? "OK" : status == 206 ? "Partial Content" : "Result") +
            "\r\nContent-Type: " + type + "\r\nContent-Length: " + length +
            "\r\nConnection: close\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff" +
            "\r\nAccess-Control-Allow-Origin: " + origin + "\r\nAccess-Control-Expose-Headers: Content-Range\r\nVary: Origin\r\n" + extra + "\r\n";
        byte[] b = Encoding.ASCII.GetBytes(text); s.Write(b, 0, b.Length);
    }
    void Reply(NetworkStream s, object value, int code = 200) {
        byte[] b = Encoding.UTF8.GetBytes(Json().Serialize(value));
        Headers(s, code, "application/json", b.Length, ""); s.Write(b, 0, b.Length);
    }
    sealed class Request {
        public string Method, Route;
        public int Length;
        public Dictionary<string,string> H = new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
    }
    Request ReadHeaders(NetworkStream s) {
        var bytes = new List<byte>();
        while (bytes.Count < 8192) {
            int b = s.ReadByte(); if (b < 0) throw new IOException("Incomplete headers.");
            bytes.Add((byte)b);
            int n = bytes.Count;
            if (n >= 4 && bytes[n-4] == 13 && bytes[n-3] == 10 && bytes[n-2] == 13 && b == 10) break;
        }
        if (bytes.Count >= 8192) throw new MovieHttpError(413, "Headers too large.");
        string[] lines = Encoding.ASCII.GetString(bytes.ToArray()).Split(new[] {"\r\n"}, StringSplitOptions.None);
        string[] first = lines[0].Split(' ');
        if (first.Length != 3 || first[2] != "HTTP/1.1") throw new MovieHttpError(400, "Invalid request.");
        var r = new Request { Method = first[0], Route = first[1] };
        foreach (string line in lines.Skip(1)) {
            if (line == "") continue;
            int split = line.IndexOf(':');
            if (split < 1 || Char.IsWhiteSpace(line[0])) throw new MovieHttpError(400, "Invalid header.");
            string key = line.Substring(0,split);
            if (r.H.ContainsKey(key)) throw new MovieHttpError(400, "Duplicate header.");
            r.H.Add(key, line.Substring(split+1).Trim());
        }
        string v;
        if (!r.H.TryGetValue("Host", out v) || v != new Uri(BaseUrl).Authority) throw new MovieHttpError(403,"Wrong host.");
        if (r.H.ContainsKey("Transfer-Encoding") || r.H.ContainsKey("Expect")) throw new MovieHttpError(400,"Unsupported framing.");
        if (r.H.TryGetValue("Content-Length",out v) && (!Regex.IsMatch(v, "^[0-9]+$") || !Int32.TryParse(v,out r.Length)))
            throw new MovieHttpError(400,"Invalid length.");
        if (r.H.TryGetValue("Origin",out v) && v != origin) throw new MovieHttpError(403,"Wrong origin.");
        // Media GETs may omit Origin, but must carry the exact product Referer.
        if (!r.H.ContainsKey("Origin")) {
            string referer;
            if (r.Method != "GET" || !r.H.TryGetValue("Referer", out referer) || !referer.StartsWith(origin + "/", StringComparison.Ordinal))
                throw new MovieHttpError(403,"Product origin required.");
        }
        if (r.Method != "GET" && r.Method != "POST" && r.Method != "OPTIONS") throw new MovieHttpError(405,"Method rejected.");
        if (r.Method != "POST" && r.Length != 0) throw new MovieHttpError(400,"Unexpected body.");
        return r;
    }
    static byte[] ReadBody(NetworkStream s, int size) {
        byte[] b = new byte[size]; int used = 0;
        while (used < size) { int n = s.Read(b,used,size-used); if (n == 0) throw new IOException("Truncated upload."); used += n; }
        return b;
    }
    Dictionary<string,object> Body(NetworkStream s, Request r) {
        if (r.Length < 2 || r.Length > 8192) throw new MovieHttpError(413,"Invalid metadata size.");
        return Json().Deserialize<Dictionary<string,object>>(Encoding.UTF8.GetString(ReadBody(s,r.Length)));
    }
    static string Str(Dictionary<string,object> b, string key) {
        object v; return b.TryGetValue(key,out v) ? Convert.ToString(v) : "";
    }
    static long Num(Dictionary<string,object> b, string key) {
        long n; if (!Int64.TryParse(Str(b,key),out n)) throw new MovieHttpError(400,"Missing numeric metadata.");
        return n;
    }
    void Serve(TcpClient c) {
        NetworkStream s = null;
        // Absolute request lifetime also bounds a peer that trickles bytes below socket timeouts.
        using (var cancelled = CancellationTokenSource.CreateLinkedTokenSource(stopping.Token))
        using (var deadline = new Timer(_ => {
            try { cancelled.Cancel(); } catch(ObjectDisposedException) {}
            try { c.Close(); } catch {}
        }, null, 10000, Timeout.Infinite)) {
            // Leave time for an explicit 408 before the socket's absolute deadline.
            var work=new MovieWork(7000,cancelled.Token,() => {
                try { return c.Client.Poll(0,SelectMode.SelectRead) && c.Client.Available==0; } catch { return true; }
            });
            try {
                c.ReceiveTimeout = 3000; c.SendTimeout = 3000;
                s = c.GetStream(); s.ReadTimeout = 3000; s.WriteTimeout = 3000;
                Request r = ReadHeaders(s);
                var audioMatch=Regex.Match(r.Route,"^/movie/"+token+"/audio/(start|chunk|sync|stop)/([a-f0-9]{32})(?:/([0-9]{1,9}))?$");
                if(audioMatch.Success) {
                    string verb=audioMatch.Groups[1].Value, lease=audioMatch.Groups[2].Value;
                    if(r.Method=="OPTIONS") {
                        string requested;
                        if(!r.H.TryGetValue("Access-Control-Request-Method",out requested)||requested!="POST")throw new MovieHttpError(403,"Audio preflight rejected.");
                        Headers(s,204,"text/plain",0,"Access-Control-Allow-Methods: POST, OPTIONS\r\nAccess-Control-Allow-Headers: Content-Type\r\n");return;
                    }
                    if(r.Method!="POST"||AudioRequest==null)throw new MovieHttpError(409,"Native PLAYBACK unavailable.");
                    Dictionary<string,object> b;byte[] samples=null;
                    if(verb=="chunk") {
                        Fail(r.Length<8||r.Length>262144||!audioMatch.Groups[3].Success,"Invalid PLAYBACK chunk.");
                        samples=ReadBody(s,r.Length);b=new Dictionary<string,object>{{"offset",audioMatch.Groups[3].Value}};
                    } else {
                        Fail(audioMatch.Groups[3].Success,"Invalid PLAYBACK route.");b=Body(s,r);
                        if(verb=="start") {var latest=LatestReceipt(work);Fail(latest==null||latest.id!=Str(b,"movie"),"PLAYBACK requires the latest eligible movie.");}
                    }
                    work.Check();object result;
                    try {result=AudioRequest(verb,lease,b,samples);}catch(Exception e){throw new MovieHttpError(409,e.Message);}
                    Reply(s,result);return;
                }
                var match = Regex.Match(r.Route, "^/movie/" + token + "/(start|chunk|prepare|commit|status|cancel|heartbeat|latest|file|preview)(?:/([a-f0-9]{32}))?(?:/([0-9]{1,8}))?$");
                if (!match.Success) throw new MovieHttpError(404,"Unknown movie route.");
                string action = match.Groups[1].Value, id = match.Groups[2].Value, seq = match.Groups[3].Value;
                bool read = action == "latest" || action == "status" || action == "file" || action == "preview";
                bool shape = action == "latest" ? id == "" && seq == "" :
                    action == "chunk" ? id != "" && seq != "" : id != "" && seq == "";
                if (!shape) throw new MovieHttpError(404,"Invalid movie route.");
                if (r.Method == "OPTIONS") {
                    string requested;
                    if (!r.H.TryGetValue("Access-Control-Request-Method",out requested) || requested != (read ? "GET" : "POST"))
                        throw new MovieHttpError(403,"Preflight rejected.");
                    if (r.H.TryGetValue("Access-Control-Request-Headers",out requested) &&
                        requested.Split(',').Any(h => h.Trim().ToLowerInvariant() != "content-type" && h.Trim().ToLowerInvariant() != "range"))
                        throw new MovieHttpError(403,"Preflight headers rejected.");
                    Headers(s,204,"text/plain",0,"Access-Control-Allow-Methods: GET, POST, OPTIONS\r\nAccess-Control-Allow-Headers: Content-Type, Range\r\n"); return;
                }
                if (r.Method != (read ? "GET" : "POST")) throw new MovieHttpError(405,"Wrong movie method.");
                if (action == "file" || action == "preview") { SendFile(s,r,id, action == "preview",work); return; }
                if (action == "latest") {
                    MovieReceipt latest = LatestReceipt(work);
                    Reply(s,new { movie = latest }); return;
                }
                if (action == "status") {
                    MovieReceipt receipt = ReadReceipt(id,work);
                    if (receipt != null) { Reply(s,new { state = "committed", movie = receipt }); return; }
                    using (work.Enter(gate)) {
                    work.Check(); MovieSession op; Reply(s,new { state = sessions.TryGetValue(id,out op) ? op.State : "absent" }); }
                    return;
                }
                if (action == "start") {
                    var b = Body(s,r);
                    using (work.Enter(gate)) {
                    work.Check();
                        ExpireLocked(work);
                        Fail(disposed,"Movie host is stopping.");
                        Fail(sessions.Count >= 128,"Too many recent movie operations.");
                        MovieSession old;
                        if (sessions.TryGetValue(id,out old)) { Fail(true,"Operation identity already used."); }
                        Fail(ReadReceipt(id,work) != null, "Operation already committed.");
                        Fail(sessions.Values.Any(x => x.State == "uploading" || x.State == "prepared"),"Movie already active.");
                        string mime = Str(b,"requestedMime");
                        string ext = MimeExtension(mime);
                        string p = Owned(id + ".media.partial",work);
                        var op = new MovieSession { Id=id, Requested=mime, Extension=ext, Partial=p,
                            File = new FileStream(p,FileMode.CreateNew,FileAccess.Write,FileShare.None,65536) };
                        sessions.Add(id,op); Reply(s,new { id=id, bytes=0, sequence=0 }); return;
                    }
                }
                if (action == "cancel") {
                    Fail(r.Length != 0,"Unexpected cancel body.");
                    using (work.Enter(gate)) {
                    work.Check(); MovieSession op; if (sessions.TryGetValue(id,out op)) Invalidate(op,"cancelled",work); }
                    Reply(s,new { state="cancelled" }); return;
                }
                using (work.Enter(gate)) {
                    work.Check();
                    MovieSession op;
                    if (!sessions.TryGetValue(id,out op)) {
                        if (action == "commit") {
                            var b = Body(s,r); MovieReceipt done=ReadReceipt(id,work);
                            Fail(done == null || Num(b,"bytes") != done.bytes || Num(b,"pieces") != done.pieces || Str(b,"validated") != "True", "Unknown commit.");
                            Reply(s,new { movie=done, state="committed" }); return;
                        }
                        throw new MovieHttpError(409,"Session not found.");
                    }
                    if (action == "heartbeat") {
                        Fail(r.Length != 0,"Unexpected heartbeat body.");
                        Fail(op.State != "uploading" && op.State != "prepared","Inactive session.");
                        op.Touched=DateTime.UtcNow; Reply(s,new { state=op.State }); return;
                    }
                    try {
                        Fail(disposed,"Movie host is stopping.");
                        if (action == "commit" && op.State == "committed") {
                            var repeated = Body(s,r);
                            Fail(Num(repeated,"bytes") != op.Receipt.bytes || Num(repeated,"pieces") != op.Receipt.pieces ||
                                Str(repeated,"validated") != "True", "Commit totals changed.");
                            Reply(s,new { state="committed", movie=op.Receipt }); return;
                        }
                        Fail(op.State != "uploading" && op.State != "prepared","Session cannot commit.");
                        Fail((DateTime.UtcNow-op.Created).TotalSeconds > 345,"Movie duration expired.");
                        if (action == "chunk") {
                            Fail(op.State != "uploading" || Int32.Parse(seq) != op.Sequence,"Chunk sequence rejected.");
                            Fail(r.Length < 1 || r.Length > PieceLimit || op.Bytes+r.Length > TotalLimit,"Movie size limit.");
                            // At most one transport piece retained by worker; no whole-clip buffering.
                            byte[] bytes = ReadBody(s,r.Length);
                            Safe(op.Partial,work); work.Check(); op.File.Write(bytes,0,bytes.Length); work.Check();
                            op.Bytes += bytes.Length; op.Sequence++; op.Touched=DateTime.UtcNow;
                            Reply(s,new { bytes=op.Bytes, sequence=op.Sequence }); return;
                        }
                        if (action == "prepare") {
                            var b=Body(s,r);
                            Fail(op.State != "uploading" || Str(b,"ended") != "True" || Num(b,"pieces") != op.Sequence ||
                                Num(b,"bytes") != op.Bytes || op.Bytes == 0,"Recording not complete.");
                            string mime=Str(b,"recorderMime");
                            Fail(MimeExtension(mime) != op.Extension,"Recorder format changed.");
                            op.Reported=mime; work.Check(); op.File.Flush(true); work.Check(); op.File.Dispose(); op.File=null;
                            Safe(op.Partial,work);
                            Fail(new FileInfo(op.Partial).Length != op.Bytes,"Partial length mismatch.");
                            string observed=MovieMedia.Validate(op.Partial,work);
                            Fail(observed != op.Extension,"Container mismatch.");
                            op.PreparedHash=Hash(op.Partial,work);
                            work.Check(); op.State="prepared"; op.Touched=DateTime.UtcNow;
                            Reply(s,new { state="prepared", container=observed, bytes=op.Bytes }); return;
                        }
                        if (action == "commit") {
                            var b=Body(s,r);
                            Fail(op.State != "prepared" || Str(b,"validated") != "True" || Num(b,"bytes") != op.Bytes ||
                                Num(b,"pieces") != op.Sequence,"Validation acknowledgement missing.");
                            Safe(op.Partial,work);
                            Fail(new FileInfo(op.Partial).Length != op.Bytes,"Prepared file changed.");
                            string observed=MovieMedia.Validate(op.Partial,work);
                            Fail(Hash(op.Partial,work) != op.PreparedHash,"Prepared media changed after validation.");
                            string finalName=FinalFileName(observed,work);
                            var receipt=new MovieReceipt { id=id, fileName=finalName,
                                completedUtc=DateTime.UtcNow.ToString("o"), bytes=op.Bytes, pieces=op.Sequence,
                                requestedMime=op.Requested, recorderMime=op.Reported, container=observed,
                                codecs=ReportedCodecs(op.Reported), sha256=op.PreparedHash, validation="structure-and-browser-decode-seek" };
                            string dest=Owned(receipt.fileName,work), temp=Owned(id+".receipt.partial",work), final=Owned(id+".json",work);
                            work.Check();
                            using (var f=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None)) {
                                byte[] json=Encoding.UTF8.GetBytes(Json().Serialize(receipt));
                                work.Check(); f.Write(json,0,json.Length); work.Check(); f.Flush(true); work.Check();
                            }
                            // File.Move is no-replace, including a destination directory. Receipt is publication point.
                            Fail(disposed,"Movie host is stopping.");
                            work.Check(); File.Move(op.Partial,dest);
                            work.Check(); File.Move(temp,final);
                            op.State="committed"; op.Receipt=receipt; op.Touched=DateTime.UtcNow;
                            Reply(s,new { state="committed", movie=receipt }); return;
                        }
                        throw new MovieHttpError(404,"Unknown action.");
                    } catch { if (op.State != "committed") Invalidate(op,"failed",work); throw; }
                }
            } catch (Exception e) {
                try { if (s != null) Reply(s,new { error=e is OperationCanceledException ? "Movie storage work cancelled or deadline exceeded." : e is MovieHttpError ? e.Message : "Movie I/O failed." }, e is OperationCanceledException ? 408 : e is MovieHttpError ? ((MovieHttpError)e).Status : 409); } catch {}
                // Deliver the rejection before closing a socket with an unread request body.
                try {
                    c.Client.Shutdown(SocketShutdown.Send); s.ReadTimeout=100;
                    byte[] discard=new byte[4096]; int drained=0, n;
                    while(drained < PieceLimit+8192 && (n=s.Read(discard,0,discard.Length))>0) drained+=n;
                } catch {}
            } finally { try { c.Close(); } catch {} lock(clientsGate) { clients.Remove(c); } }
        }
    }
    static string MimeExtension(string mime) {
        if (mime.Length > 256) throw new MovieHttpError(400,"Invalid MIME.");
        if (Regex.IsMatch(mime, "^video/mp4(?:;[^\r\n]*)?$",RegexOptions.IgnoreCase)) return "mp4";
        if (Regex.IsMatch(mime, "^video/webm(?:;[^\r\n]*)?$",RegexOptions.IgnoreCase)) return "webm";
        throw new MovieHttpError(400,"Unsupported MIME.");
    }
    static string ReportedCodecs(string mime) {
        Match m=Regex.Match(mime,"(?:^|;)\\s*codecs=([^;]+)",RegexOptions.IgnoreCase);
        return m.Success ? m.Groups[1].Value.Trim().Trim('"') : null;
    }
    static string Hash(string path,MovieWork work) {
        work.Check();
        using(var f=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read))
            return MovieStorage.Hash(f,work);
    }
    string FinalFileName(string extension,MovieWork work) {
        string stem="MOVIE_"+DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");
        for(int suffix=0;suffix<=999;suffix++) {
            work.Check();
            string name=stem+(suffix==0 ? "" : "_"+suffix)+"."+extension;
            string candidate=Owned(name,work);
            if(!File.Exists(candidate)) return name;
        }
        throw new MovieHttpError(409,"Movie filename collision limit exceeded.");
    }
    MovieReceipt ReadReceiptMetadata(string id,MovieWork work) {
        try {
            work.Check();
            string p=Owned(id+".json",work); if (!File.Exists(p)) return null;
            SingleLink(p,work);
            string json;
            using(var f=new FileStream(p,FileMode.Open,FileAccess.Read,FileShare.Read)) {
                var input=new MovieReadStream(f,work);
                if(input.Length>8192) return null;
                byte[] buffer=new byte[8193]; int used=0,n;
                while(used<buffer.Length && (n=input.Read(buffer,used,buffer.Length-used))>0) used+=n;
                if(used>8192) return null;
                json=Encoding.UTF8.GetString(buffer,0,used);
            }
            work.Check();
            MovieReceipt r=Json().Deserialize<MovieReceipt>(json);
            if (r == null || r.id != id || r.validation != "structure-and-browser-decode-seek" ||
                !Regex.IsMatch(r.fileName ?? "", "^MOVIE_[0-9]{8}_[0-9]{6}_[0-9]{3}(?:_[1-9][0-9]{0,2})?\\.(mp4|webm)$") ||
                (r.container != "mp4" && r.container != "webm") || !r.fileName.EndsWith("."+r.container) ||
                r.bytes <= 0 || r.bytes > TotalLimit || r.pieces <= 0 || MimeExtension(r.recorderMime) != r.container ||
                MimeExtension(r.requestedMime) != r.container) return null;
            DateTime stamp; if (!DateTime.TryParse(r.completedUtc,out stamp)) return null;
            work.Check(); return r;
        } catch(OperationCanceledException) { throw; }
        catch { work.Check(); return null; }
    }
    bool Eligible(MovieReceipt r,MovieWork work) {
        try {
            string media=Owned(r.fileName,work);
            if(!File.Exists(media)) return false;
            SingleLink(media,work);
            work.Check();
            if(new FileInfo(media).Length!=r.bytes) return false;
            return Hash(media,work)==r.sha256;
        } catch(OperationCanceledException) { throw; }
        catch { work.Check(); return false; }
    }
    MovieReceipt ReadReceipt(string id,MovieWork work) {
        var r=ReadReceiptMetadata(id,work);
        return r!=null && Eligible(r,work) ? r : null;
    }
    MovieReceipt LatestReceipt(MovieWork work) {
        // Bound metadata memory/work; never call a truncated scan "latest".
        // Read small receipts first, then hash newest candidates only until success.
        const int receiptsLimit=4096, candidatesLimit=32;
        CheckTree(directory,work);
        var candidates=new List<MovieReceipt>(); int entries=0;
        using(var files=Directory.EnumerateFiles(directory,"*.json").GetEnumerator()) {
            while(true) {
                work.Check(); bool more=files.MoveNext(); work.Check(); if(!more) break;
                if(++entries>receiptsLimit) throw new MovieHttpError(503,"Movie receipt discovery limit exceeded.");
                string id=Path.GetFileNameWithoutExtension(files.Current);
                if(!Regex.IsMatch(id,"^[a-f0-9]{32}$")) continue;
                var receipt=ReadReceiptMetadata(id,work); if(receipt!=null) candidates.Add(receipt);
            }
        }
        work.Check();
        candidates.Sort((x,y) => {
            int order=StringComparer.Ordinal.Compare(y.completedUtc,x.completedUtc);
            return order!=0 ? order : StringComparer.Ordinal.Compare(y.id,x.id);
        });
        work.Check(); int checkedCandidates=0;
        foreach(var receipt in candidates) {
            work.Check();
            if(++checkedCandidates>candidatesLimit) throw new MovieHttpError(503,"Movie eligibility candidate limit exceeded.");
            if(Eligible(receipt,work)) { work.Check(); return receipt; }
        }
        work.Check(); return null;
    }
    void SendFile(NetworkStream s, Request request, string id, bool preview, MovieWork work) {
        string path, type; long size;
        if (preview) {
            using(work.Enter(gate)) {
                work.Check();
                MovieSession op; Fail(!sessions.TryGetValue(id,out op) || op.State != "prepared","No prepared movie.");
                path=Safe(op.Partial,work); type="video/"+op.Extension; size=op.Bytes; op.Touched=DateTime.UtcNow;
            }
        } else {
            MovieReceipt r=ReadReceipt(id,work); Fail(r == null,"Movie is not eligible.");
            path=Owned(r.fileName,work); type="video/"+r.container; size=r.bytes;
        }
        long first=0, last=size-1; int status=200; string range;
        if (request.H.TryGetValue("Range",out range)) {
            Match m=Regex.Match(range,"^bytes=([0-9]*)-([0-9]*)$"); long a,b;
            if (!m.Success || (m.Groups[1].Value == "" && m.Groups[2].Value == "")) {
                Headers(s,416,type,0,"Content-Range: bytes */"+size+"\r\n"); return;
            }
            if (m.Groups[1].Value == "") {
                if (!Int64.TryParse(m.Groups[2].Value,out b) || b <= 0) { Headers(s,416,type,0,"Content-Range: bytes */"+size+"\r\n"); return; }
                first=Math.Max(0,size-b);
            } else {
                if (!Int64.TryParse(m.Groups[1].Value,out a) || a >= size ||
                    (m.Groups[2].Value != "" && (!Int64.TryParse(m.Groups[2].Value,out b) || b < a))) {
                    Headers(s,416,type,0,"Content-Range: bytes */"+size+"\r\n"); return;
                }
                first=a;
                if (m.Groups[2].Value != "") last=Math.Min(last,Int64.Parse(m.Groups[2].Value));
            }
            status=206;
            // Browser video often asks for bytes=N-. Serve a finite, correctly
            // described range so backpressure cannot tie one request to clip length.
            last=Math.Min(last,first+4L*1024*1024-1);
        }
        Safe(path,work);
        SingleLink(path,work);
        using (var f=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read | FileShare.Delete)) {
            Fail(f.Length != size,"Movie changed.");
            Headers(s,status,type,last-first+1,"Accept-Ranges: bytes\r\n"+(status==206 ? "Content-Range: bytes "+first+"-"+last+"/"+size+"\r\n" : ""));
            f.Position=first; long left=last-first+1; byte[] buffer=new byte[65536];
            while(left>0 && !disposed) {
                work.Check(); int n=f.Read(buffer,0,(int)Math.Min(buffer.Length,left)); work.Check(); if(n==0) throw new IOException();
                s.Write(buffer,0,n); left-=n;
            }
        }
    }
    void Invalidate(MovieSession op,string state,MovieWork work = null) {
        if(op.State=="committed") return;
        op.State=state; op.Touched=DateTime.UtcNow;
        if(op.File!=null) { try { op.File.Dispose(); } catch {} op.File=null; }
        try { Safe(op.Partial,work); if(File.Exists(op.Partial)) { MovieWork.Check(work); File.Delete(op.Partial); } } catch {}
        try { string p=Owned(op.Id+".receipt.partial",work); if(File.Exists(p)) { MovieWork.Check(work); File.Delete(p); } } catch {}
    }
    void ExpireLocked(MovieWork work = null) {
        foreach(var op in sessions.Values.ToArray()) {
            MovieWork.Check(work);
            if((op.State=="uploading" || op.State=="prepared") &&
                ((DateTime.UtcNow-op.Touched).TotalSeconds>30 || (DateTime.UtcNow-op.Created).TotalSeconds>345)) Invalidate(op,"expired",work);
            if(op.State!="uploading" && op.State!="prepared" && (DateTime.UtcNow-op.Touched).TotalSeconds>60) sessions.Remove(op.Id);
        }
    }
    void Expire(object unused) {
        if(disposed || !Monitor.TryEnter(gate)) return;
        try { if(!disposed) ExpireLocked(); } finally { Monitor.Exit(gate); }
    }
    public void Dispose() {
        if(disposed) return; disposed=true; stopping.Cancel(); expiry.Dispose(); listener.Stop();
        Thread[] pending;
        lock(clientsGate) { foreach(var c in clients) { try { c.Close(); } catch {} } pending=threads.ToArray(); }
        acceptThread.Join(1000);
        var until = DateTime.UtcNow.AddSeconds(2);
        foreach(var t in pending) t.Join(Math.Max(0,(int)(until-DateTime.UtcNow).TotalMilliseconds));
        // Never flush/dispose a disk file on the control thread. A stalled filesystem
        // must not strand host shutdown; all cleanup threads die with the host process.
        var cleanup = new Thread(() => {
            lock(gate) { foreach(var op in sessions.Values) Invalidate(op,"cancelled"); sessions.Clear(); }
        }) { IsBackground=true, Name="Remocon movie cleanup" };
        cleanup.Start(); cleanup.Join(100);
    }
}

// Deliberately structural, not a decoder. Browser decode/seek is also required before commit.
public static class MovieMedia {
    static void Need(bool ok) { if(!ok) throw new IOException("Invalid or incomplete movie container."); }
    static uint U32(Stream f) {
        byte[] b=new byte[4]; Need(f.Read(b,0,4)==4);
        return ((uint)b[0]<<24)|((uint)b[1]<<16)|((uint)b[2]<<8)|b[3];
    }
    static ulong Vint(Stream f,bool id,out bool unknown) {
        int first=f.ReadByte(); Need(first>0); int n=1, mask=128;
        while((first&mask)==0) { n++; mask>>=1; } Need(n <= (id?4:8));
        ulong v=(ulong)(id?first:first&(mask-1)), all=(ulong)(mask-1);
        for(int i=1;i<n;i++){ int b=f.ReadByte(); Need(b>=0); v=(v<<8)|(uint)b; all=(all<<8)|255; }
        unknown=!id && v==all; return v;
    }
    static void Ebml(Stream f,long end,int depth,HashSet<ulong> seen, ref bool video,ref bool audio, bool openCluster = false) {
        Need(depth<12);
        while(f.Position<end) {
            long start=f.Position;
            bool unused,unknown; ulong id=Vint(f,true,out unused);
            if(openCluster && (id==0x1F43B675 || id==0x1C53BB6B || id==0x1549A966 || id==0x1654AE6B || id==0x114D9B74)) {
                f.Position=start; return;
            }
            ulong length=Vint(f,false,out unknown);
            Need(length<=(ulong)(end-f.Position) || (unknown && (id==0x18538067 || id==0x1F43B675)));
            long limit=unknown?end:f.Position+(long)length; seen.Add(id);
            if(id==0x18538067 || id==0x1F43B675 || id==0x1654AE6B || id==0xAE || id==0x1A45DFA3 || id==0xA0)
                Ebml(f,limit,depth+1,seen,ref video,ref audio,unknown && id==0x1F43B675);
            else if(id==0x83) {
                Need(length==1); int type=f.ReadByte(); video|=type==1; audio|=type==2;
            } else if(id==0x4282) {
                Need(length==4); byte[] b=new byte[4]; Need(f.Read(b,0,4)==4 && Encoding.ASCII.GetString(b)=="webm");
            } else f.Position=limit;
            Need((unknown && id==0x1F43B675) || f.Position==limit);
        }
        Need(f.Position==end);
    }
    static void Boxes(Stream f,long end,int depth,HashSet<string> seen,ref bool video,ref bool audio) {
        Need(depth<12);
        while(f.Position<end) {
            long start=f.Position; Need(end-start>=8); ulong size=U32(f);
            byte[] b=new byte[4]; Need(f.Read(b,0,4)==4); string type=Encoding.ASCII.GetString(b);
            if(size==1) size=((ulong)U32(f)<<32)|U32(f);
            Need(size>= (ulong)(f.Position-start) && size<=(ulong)(end-start));
            long limit=start+(long)size; seen.Add(type);
            if(type=="moov"||type=="trak"||type=="mdia"||type=="minf"||type=="stbl"||type=="moof"||type=="traf"||type=="mvex")
                Boxes(f,limit,depth+1,seen,ref video,ref audio);
            else if(type=="hdlr") {
                Need(limit-f.Position>=12); f.Position+=8; Need(f.Read(b,0,4)==4);
                string handler=Encoding.ASCII.GetString(b); video|=handler=="vide"; audio|=handler=="soun"; f.Position=limit;
            } else f.Position=limit;
            Need(f.Position==limit);
        }
    }
    public static string Validate(string path) { return Validate(path,new MovieWork(7000,CancellationToken.None)); }
    public static string Validate(string path,MovieWork work) {
        work.Check();
        using(var f=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read))
            return Validate(f,work);
    }
    public static string Validate(Stream input,MovieWork work) {
        using(var f=new MovieReadStream(input,work)) {
            Need(f.Length>=32); uint head=U32(f); f.Position=0; bool video=false,audio=false;
            if(head==0x1A45DFA3) {
                var seen=new HashSet<ulong>(); Ebml(f,f.Length,0,seen,ref video,ref audio);
                Need(video&&audio&&seen.Contains(0x4282)&&seen.Contains(0x18538067)&&seen.Contains(0x1654AE6B)&&
                     seen.Contains(0x1F43B675)&&(seen.Contains(0xA3)||seen.Contains(0xA1)));
                return "webm";
            }
            var boxes=new HashSet<string>(); Boxes(f,f.Length,0,boxes,ref video,ref audio);
            Need(video&&audio&&boxes.Contains("ftyp")&&boxes.Contains("moov")&&boxes.Contains("mdat"));
            return "mp4";
        }
    }
}
}
