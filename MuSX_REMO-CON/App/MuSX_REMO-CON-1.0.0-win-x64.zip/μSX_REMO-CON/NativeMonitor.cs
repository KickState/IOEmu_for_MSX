// Production monitor: explicitly selected capture -> bounded clock bridge ->
// exact shared-mode render. Browser capture remains independently owned by MOVIE.
// No endpoint/session volume setters, defaults, loopback, exclusive mode or RAW.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;

namespace RemoLive {
    public sealed class DeviceInfo { public string Id, Name; public int Flow; }
    static class Com {
        [DllImport("ole32.dll")] internal static extern int CoInitializeEx(IntPtr p, uint flags);
        [DllImport("ole32.dll")] internal static extern void CoUninitialize();
        [DllImport("ole32.dll")] internal static extern int PropVariantClear(ref Variant value);
        internal static void HR(int hr, string stage) { if (hr < 0) throw new COMException(stage + " [0x" + hr.ToString("X8") + "]", hr); }
        internal static void Release(object o) { if (o != null && Marshal.IsComObject(o)) Marshal.ReleaseComObject(o); }
        internal static T STA<T>(Func<T> action) {
            T result = default(T); Exception error = null;
            var thread = new Thread(() => { bool initialized = false;
                try { HR(CoInitializeEx(IntPtr.Zero, 2), "COM STA"); initialized = true; result = action(); }
                catch (Exception e) { error = e; }
                finally { if (initialized) CoUninitialize(); }
            });
            thread.IsBackground = true; thread.SetApartmentState(ApartmentState.STA); thread.Start();
            if (!thread.Join(10000)) throw new TimeoutException("Audio device enumeration timed out; no fallback.");
            if (error != null) throw new InvalidOperationException("Audio device inspection failed.", error);
            return result;
        }
    }
    public static class Devices {
        public static DeviceInfo[] List() { return Com.STA(Read); }
        internal static DeviceInfo[] Read() {
            var result = new List<DeviceInfo>(); IDevices devices = null;
            try {
                devices = (IDevices)new DeviceEnumerator();
                for (int flow = 0; flow <= 1; flow++) {
                    ICollection collection = null;
                    try {
                        Com.HR(devices.EnumAudioEndpoints(flow, 1, out collection), "Enumerate active endpoints");
                        uint count; Com.HR(collection.GetCount(out count), "Endpoint count");
                        for (uint i = 0; i < count; i++) {
                            IDevice device = null; IProperties properties = null;
                            try {
                                Com.HR(collection.Item(i, out device), "Endpoint item");
                                string id; Com.HR(device.GetId(out id), "Endpoint ID");
                                Com.HR(device.OpenPropertyStore(0, out properties), "Read endpoint properties");
                                var key = new PropertyKey { Format = new Guid("A45C254E-DF1C-4EFD-8020-67D146A850E0"), Id = 14 };
                                Variant value; Com.HR(properties.GetValue(ref key, out value), "Endpoint friendly name");
                                try {
                                    if (value.Type != 31) throw new InvalidOperationException("Endpoint name is not a string.");
                                    result.Add(new DeviceInfo { Id = id, Name = Marshal.PtrToStringUni(value.Pointer), Flow = flow });
                                } finally { Com.PropVariantClear(ref value); }
                            } finally { Com.Release(properties); Com.Release(device); }
                        }
                    } finally { Com.Release(collection); }
                }
            } finally { Com.Release(devices); }
            return result.ToArray();
        }
        public static void Validate(DeviceInfo[] devices, string input, string output) {
            if (String.IsNullOrEmpty(input) || devices.Count(d => d.Flow == 1 && d.Id == input) != 1)
                throw new InvalidOperationException("Choose an available Audio input; no default-device fallback.");
            if (String.IsNullOrEmpty(output) || devices.Count(d => d.Flow == 0 && d.Id == output) != 1)
                throw new InvalidOperationException("Choose an available Audio output; no default-device fallback.");
        }
    }
    public sealed class PcmFormat {
        public int Rate, Channels, Bits, Block; public bool Floating;
        public static PcmFormat Parse(byte[] bytes) {
            if (bytes.Length < 18) throw new InvalidOperationException("Short audio format.");
            int tag = BitConverter.ToUInt16(bytes, 0), channels = BitConverter.ToUInt16(bytes, 2);
            int rate = BitConverter.ToInt32(bytes, 4), bits = BitConverter.ToUInt16(bytes, 14), block = BitConverter.ToUInt16(bytes, 12);
            if (tag == 65534) {
                if (bytes.Length < 40 || BitConverter.ToUInt16(bytes,16) < 22) throw new InvalidOperationException("Short extensible format.");
                var sub = new byte[16]; Array.Copy(bytes,24,sub,0,16); var guid = new Guid(sub);
                if (guid == new Guid("00000001-0000-0010-8000-00aa00389b71")) tag = 1;
                else if (guid == new Guid("00000003-0000-0010-8000-00aa00389b71")) tag = 3;
                else throw new InvalidOperationException("Unsupported capture subformat.");
                int valid = BitConverter.ToUInt16(bytes,18);
                if (valid < 1 || valid > bits) throw new InvalidOperationException("Invalid capture precision.");
                uint mask = BitConverter.ToUInt32(bytes,20);
                if ((channels == 2 && mask != 0 && mask != 3) || (channels == 1 && mask != 0 && mask != 4))
                    throw new InvalidOperationException("Unsupported capture channel layout.");
            }
            if (rate < 8000 || rate > 192000 || channels < 1 || channels > 2 ||
                !((tag == 3 && bits == 32) || (tag == 1 && (bits == 16 || bits == 24 || bits == 32))) || block != channels * bits / 8)
                throw new InvalidOperationException("Unsupported capture format; no silent format guess.");
            return new PcmFormat { Rate = rate, Channels = channels, Bits = bits, Block = block, Floating = tag == 3 };
        }
        public void Decode(byte[] bytes, int frames, float[] stereo) {
            for (int f = 0; f < frames; f++) for (int c = 0; c < 2; c++) {
                int offset = f * Block + Math.Min(c, Channels - 1) * Bits / 8;
                float value;
                if (Floating) value = BitConverter.ToSingle(bytes, offset);
                else if (Bits == 16) value = BitConverter.ToInt16(bytes, offset) / 32768f;
                else if (Bits == 24) { int v = bytes[offset] | bytes[offset+1] << 8 | bytes[offset+2] << 16; value = (v << 8) / 2147483648f; }
                else value = BitConverter.ToInt32(bytes, offset) / 2147483648f;
                if (Single.IsNaN(value) || Single.IsInfinity(value)) throw new InvalidOperationException("Non-finite capture sample.");
                stereo[f * 2 + c] = Math.Max(-1f, Math.Min(1f,value));
            }
        }
        internal static byte[] Read(IntPtr p) {
            int length = 18 + (ushort)Marshal.ReadInt16(p,16);
            if (length > 4096) throw new InvalidOperationException("Unexpected audio format size.");
            var bytes = new byte[length]; Marshal.Copy(p, bytes, 0, length); return bytes;
        }
    }
    // Small bounded stereo FIFO. Fractional interpolation compensates independent
    // USB/output clocks, without dropping/duplicating entire packets during drift.
    public sealed class ClockBridge {
        readonly float[] samples; readonly int capacity, target, rate;
        int head, count; double fraction, ratio = 1, filtered;
        public int Buffered { get { return count; } }
        public double Ratio { get { return ratio; } }
        public long UnderrunFrames { get; private set; }
        public ClockBridge(int sampleRate) {
            rate = sampleRate; capacity = rate / 4; target = rate / 25; // 250ms bound, 40ms target
            samples = new float[capacity * 2]; filtered = target;
        }
        public void Push(float[] values, int frames) {
            if (frames < 0 || frames * 2 > values.Length || frames > capacity - count)
                throw new InvalidOperationException("Native monitor buffer overflow; stopped rather than accumulating latency.");
            for (int i=0;i<frames;i++) { int j = ((head+count+i)%capacity)*2; samples[j]=values[i*2]; samples[j+1]=values[i*2+1]; }
            count += frames;
        }
        public void Pull(float[] output, int frames, float gain) {
            // Low-pass occupancy to avoid tracking individual endpoint packet jitter.
            double alpha = 1 - Math.Exp(-frames / (double)rate);
            filtered += alpha * (count - filtered);
            double desired = 1 + Math.Max(-0.002,Math.Min(0.002,(filtered-target)/(rate*5.0)));
            ratio += alpha * (desired-ratio);
            for (int i=0;i<frames;i++) {
                if (count < 3) { output[i*2]=output[i*2+1]=0; UnderrunFrames++; continue; }
                int next=(head+1)%capacity;
                for(int c=0;c<2;c++) output[i*2+c]=(float)(samples[head*2+c]*(1-fraction)+samples[next*2+c]*fraction)*gain;
                fraction += ratio;
                int consumed = (int)fraction;
                consumed = Math.Min(consumed,count-1);
                head=(head+consumed)%capacity; count-=consumed; fraction-=consumed;
            }
        }
    }
    public sealed class MonitorInfo {
        public string State = "Starting", Error = "", InputId, OutputId, CaptureFormat, RenderFormat;
        public int SampleRate, BufferedFrames;
        public long CapturedFrames, RenderedFrames, UnderrunFrames, Discontinuities;
        public double ClockRatio = 1;
        public string Mode = "Shared; Media; non-offloaded; application-only gain; no browser live render";
    }
    public sealed class Monitor : IDisposable {
        readonly ManualResetEvent stop = new ManualResetEvent(false), ready = new ManualResetEvent(false);
        readonly Thread thread; readonly object sync = new object(); readonly MonitorInfo info;
        readonly Stopwatch lease = Stopwatch.StartNew();
        long heartbeat; volatile float gain; bool disposed;
        public bool Alive { get { return thread.IsAlive; } }
        public Monitor(string input, string output, float initialGain) {
            info = new MonitorInfo { InputId=input, OutputId=output }; gain=initialGain;
            thread=new Thread(Run); thread.IsBackground=true; thread.SetApartmentState(ApartmentState.STA); thread.Start();
        }
        public void AwaitReady() { if (!ready.WaitOne(8000)) { stop.Set(); throw new TimeoutException("Native monitor start timed out."); } if (Snapshot().State != "Running") throw new InvalidOperationException(Snapshot().Error); }
        public void Touch() { Interlocked.Exchange(ref heartbeat,lease.ElapsedMilliseconds); }
        public void Gain(float value) { if (Single.IsNaN(value) || value < 0 || value > 1) throw new ArgumentException("Invalid monitor volume."); gain=value; }
        public MonitorInfo Snapshot() { lock(sync) return new MonitorInfo {
            State=info.State,Error=info.Error,InputId=info.InputId,OutputId=info.OutputId,CaptureFormat=info.CaptureFormat,RenderFormat=info.RenderFormat,
            SampleRate=info.SampleRate,BufferedFrames=info.BufferedFrames,CapturedFrames=info.CapturedFrames,RenderedFrames=info.RenderedFrames,
            UnderrunFrames=info.UnderrunFrames,Discontinuities=info.Discontinuities,ClockRatio=info.ClockRatio }; }
        void Run() {
            IDevices devices=null; IDevice input=null,output=null; object capObject=null,outObject=null,capService=null,outService=null;
            IAudioClient capture=null; IAudioClient2 render=null; IntPtr capFormat=IntPtr.Zero,outFormat=IntPtr.Zero,sessionPointer=IntPtr.Zero; bool initialized=false,capStarted=false,outStarted=false;
            using(var capEvent=new AutoResetEvent(false)) using(var outEvent=new AutoResetEvent(false)) {
                try {
                    Com.HR(Com.CoInitializeEx(IntPtr.Zero,2),"COM STA"); initialized=true;
                    Devices.Validate(Devices.Read(),info.InputId,info.OutputId);
                    devices=(IDevices)new DeviceEnumerator();
                    Com.HR(devices.GetDevice(info.InputId,out input),"Exact capture endpoint");
                    Com.HR(devices.GetDevice(info.OutputId,out output),"Exact render endpoint");
                    Guid iid=typeof(IAudioClient).GUID;
                    Com.HR(input.Activate(ref iid,23,IntPtr.Zero,out capObject),"Activate capture");
                    iid=typeof(IAudioClient2).GUID;
                    Com.HR(output.Activate(ref iid,23,IntPtr.Zero,out outObject),"Activate render");
                    capture=(IAudioClient)capObject; render=(IAudioClient2)outObject;
                    var properties=new ClientProperties { Size=16,Category=11 };
                    Com.HR(render.SetClientProperties(ref properties),"Media render properties");
                    Com.HR(capture.GetMixFormat(out capFormat),"Capture mix format");
                    byte[] formatBytes=PcmFormat.Read(capFormat); PcmFormat format=PcmFormat.Parse(formatBytes);
                    // Capture uses its exact engine format. Windows converts stereo float
                    // render at that nominal rate to the explicitly selected output mix.
                    outFormat=Marshal.AllocCoTaskMem(18); var renderBytes=new byte[18];
                    Array.Copy(BitConverter.GetBytes((ushort)3),0,renderBytes,0,2);
                    Array.Copy(BitConverter.GetBytes((ushort)2),0,renderBytes,2,2);
                    Array.Copy(BitConverter.GetBytes(format.Rate),0,renderBytes,4,4);
                    Array.Copy(BitConverter.GetBytes(format.Rate*8),0,renderBytes,8,4);
                    Array.Copy(BitConverter.GetBytes((ushort)8),0,renderBytes,12,2);
                    Array.Copy(BitConverter.GetBytes((ushort)32),0,renderBytes,14,2); Marshal.Copy(renderBytes,0,outFormat,18);
                    lock(sync) { info.CaptureFormat=BitConverter.ToString(formatBytes); info.RenderFormat=BitConverter.ToString(renderBytes); info.SampleRate=format.Rate; }
                    IntPtr closest;
                    int supported=capture.IsFormatSupported(0,capFormat,out closest);
                    if(closest!=IntPtr.Zero)Marshal.FreeCoTaskMem(closest);
                    if(supported!=0)throw new InvalidOperationException("Capture mix format was not accepted exactly; no fallback.");
                    sessionPointer=Marshal.AllocCoTaskMem(16); Marshal.StructureToPtr(Guid.NewGuid(),sessionPointer,false);
                    Com.HR(render.Initialize(0,0x880C0000,0,0,outFormat,sessionPointer),"Initialize shared converted render");
                    Com.HR(capture.Initialize(0,0x00040000,0,0,capFormat,IntPtr.Zero),"Initialize shared capture (mix support=0x"+supported.ToString("X8")+")");
                    Com.HR(capture.SetEventHandle(capEvent.SafeWaitHandle.DangerousGetHandle()),"Capture event");
                    Com.HR(render.SetEventHandle(outEvent.SafeWaitHandle.DangerousGetHandle()),"Render event");
                    iid=typeof(ICapture).GUID; Com.HR(capture.GetService(ref iid,out capService),"Capture client");
                    iid=typeof(IRender).GUID; Com.HR(render.GetService(ref iid,out outService),"Render client");
                    var reader=(ICapture)capService; var writer=(IRender)outService;
                    uint outFrames; Com.HR(render.GetBufferSize(out outFrames),"Render buffer size");
                    if (outFrames == 0 || outFrames > format.Rate/5) throw new InvalidOperationException("Unsupported render latency (>200ms).");
                    var bridge=new ClockBridge(format.Rate);
                    var raw=new byte[format.Rate*format.Block/4]; var decoded=new float[format.Rate/2]; var mixed=new float[outFrames*2];
                    if(stop.WaitOne(0)) return;
                    Com.HR(capture.Start(),"Start native capture"); capStarted=true;
                    long captureTime=lease.ElapsedMilliseconds, rendered=0,captured=0,discontinuities=0;
                    var waits=new WaitHandle[]{stop,capEvent,outEvent};
                    while(!stop.WaitOne(0)) {
                        if(lease.ElapsedMilliseconds-Interlocked.Read(ref heartbeat)>8000) throw new InvalidOperationException("Monitor heartbeat expired; stopped.");
                        uint packet; Com.HR(reader.GetNextPacketSize(out packet),"Capture packet size");
                        int batches=0;
                        while(packet>0) {
                            if(++batches>128) throw new InvalidOperationException("Capture backlog exceeded bound.");
                            IntPtr buffer; uint frames,flags; ulong position,qpc;
                            Com.HR(reader.GetBuffer(out buffer,out frames,out flags,out position,out qpc),"Capture buffer");
                            try {
                                if(frames>format.Rate/4) throw new InvalidOperationException("Capture packet exceeded bound.");
                                if((flags&1)!=0) discontinuities++;
                                if((flags&2)!=0) Array.Clear(decoded,0,(int)frames*2);
                                else { Marshal.Copy(buffer,raw,0,(int)frames*format.Block); format.Decode(raw,(int)frames,decoded); }
                                bridge.Push(decoded,(int)frames); captured+=frames; captureTime=lease.ElapsedMilliseconds;
                            } finally { Com.HR(reader.ReleaseBuffer(frames),"Release capture packet"); }
                            Com.HR(reader.GetNextPacketSize(out packet),"Next capture packet");
                        }
                        if(lease.ElapsedMilliseconds-captureTime>1000) throw new InvalidOperationException("Selected audio capture stalled; monitor stopped.");
                        if(!outStarted && bridge.Buffered >= format.Rate/25 + outFrames) {
                            IntPtr buffer; Com.HR(writer.GetBuffer(outFrames,out buffer),"Initial render buffer");
                            Com.HR(writer.ReleaseBuffer(outFrames,2),"Initial render silence");
                            if(stop.WaitOne(0)) break;
                            Com.HR(render.Start(),"Start native monitor"); outStarted=true;
                            lock(sync) info.State="Running"; ready.Set();
                        }
                        if(outStarted) {
                            uint padding; Com.HR(render.GetCurrentPadding(out padding),"Render padding");
                            if(padding>outFrames) throw new InvalidOperationException("Invalid render padding.");
                            uint frames=outFrames-padding;
                            if(frames>0) {
                                float currentGain=gain; bridge.Pull(mixed,(int)frames,currentGain);
                                IntPtr buffer; Com.HR(writer.GetBuffer(frames,out buffer),"Render buffer");
                                uint flags=2;
                                try { if(currentGain>0) { Marshal.Copy(mixed,0,buffer,(int)frames*2); flags=0; } }
                                finally { Com.HR(writer.ReleaseBuffer(frames,flags),"Release render buffer"); }
                                rendered+=frames;
                            }
                            if(bridge.UnderrunFrames>format.Rate/2) throw new InvalidOperationException("Repeated monitor underruns; stopped. Restart preview to retry.");
                        }
                        lock(sync) { info.CapturedFrames=captured; info.RenderedFrames=rendered; info.Discontinuities=discontinuities;
                            info.UnderrunFrames=bridge.UnderrunFrames; info.BufferedFrames=bridge.Buffered; info.ClockRatio=bridge.Ratio; }
                        WaitHandle.WaitAny(waits,100);
                    }
                } catch(Exception e) { lock(sync) info.Error=e.Message; }
                finally {
                    try { if(outStarted) Com.HR(render.Stop(),"Stop render"); } catch(Exception e) { lock(sync) info.Error+=" "+e.Message; }
                    try { if(capStarted) Com.HR(capture.Stop(),"Stop capture"); } catch(Exception e) { lock(sync) info.Error+=" "+e.Message; }
                    Com.Release(outService); Com.Release(capService); Com.Release(outObject); Com.Release(capObject);
                    Com.Release(output); Com.Release(input); Com.Release(devices);
                    if(outFormat!=IntPtr.Zero) Marshal.FreeCoTaskMem(outFormat); if(capFormat!=IntPtr.Zero) Marshal.FreeCoTaskMem(capFormat);
                    if(sessionPointer!=IntPtr.Zero)Marshal.FreeCoTaskMem(sessionPointer);
                    if(initialized) Com.CoUninitialize();
                    lock(sync) info.State="Closed"; ready.Set();
                }
            }
        }
        public void Dispose() {
            if(disposed) return; stop.Set();
            if(!thread.Join(5000)) throw new TimeoutException("Native monitor close not acknowledged; playback remains locked.");
            disposed=true; stop.Dispose(); ready.Dispose();
        }
    }
    public sealed partial class Controller : IDisposable {
        readonly object gate = new object();
        string page,owner; Monitor monitor; MonitorInfo last;
        readonly HashSet<string> revoked=new HashSet<string>(); long sequence;
        public void NewPage(string identity) { lock(gate) { Dispose(); page=identity; revoked.Clear(); playbackRevoked.Clear(); } }
        public object Handle(string action,string identity,string lease,string input,string output,double volume,bool muted,long serial) {
            lock(gate) return HandleLive(action,identity,lease,input,output,volume,muted,serial);
        }
        object HandleLive(string action,string identity,string lease,string input,string output,double volume,bool muted,long serial) {
            if(String.IsNullOrEmpty(page) || page!=identity) throw new InvalidOperationException("Stale monitor page; reload REMO-CON.");
            if(action=="devices") return Devices.List();
            Guid parsed; if(!Guid.TryParse(lease,out parsed)) throw new InvalidOperationException("Missing monitor lease.");
            if(action=="stop") {
                if(revoked.Count>=10000) throw new InvalidOperationException("Reload to renew monitor ownership.");
                revoked.Add(lease); if(owner==lease) Stop(); return Status();
            }
            if(revoked.Contains(lease)) throw new InvalidOperationException("Monitor lease revoked; no late restart.");
            if(Double.IsNaN(volume) || Double.IsInfinity(volume) || volume<0 || volume>1) throw new ArgumentException("Invalid monitor volume.");
            if(action=="start") {
                if(playback!=null) throw new InvalidOperationException("PLAYBACK owns audio; close it before LIVE.");
                if(owner!=null) throw new InvalidOperationException("A monitor already owns the live path.");
                Devices.Validate(Devices.List(),input,output);
                owner=lease; sequence=serial;
                monitor=new Monitor(input,output,muted?0:(float)volume);
                try { monitor.AwaitReady(); } catch { Stop(); throw; }
            } else {
                if(owner!=lease || monitor==null) throw new InvalidOperationException("No live monitor lease; restart preview.");
                if(!monitor.Alive) { string error=monitor.Snapshot().Error; Stop(); throw new InvalidOperationException(error); }
                if(action!="pulse" && action!="volume") throw new InvalidOperationException("Unknown monitor action.");
                if(action=="volume" && serial>sequence) { monitor.Gain(muted?0:(float)volume); sequence=serial; }
                monitor.Touch();
            }
            return Status();
        }
        object Status() { return new { Closed=monitor==null, Monitor=monitor==null?last:monitor.Snapshot() }; }
        void Stop() { if(monitor!=null) { monitor.Dispose(); last=monitor.Snapshot(); monitor=null; } owner=null; }
        public void Dispose() { lock(gate) { StopPlayback(); Stop(); page=null; } }
    }
    // Whole-clip PCM is bounded by the existing five-minute recording limit.
    // Only this worker touches WASAPI. The browser's offline decoder owns no output.
    public sealed class Playback : IDisposable {
        const int Rate=48000;
        float[] pcm;
        readonly string output;
        readonly object sync=new object();
        readonly ManualResetEvent stop=new ManualResetEvent(false), ready=new ManualResetEvent(false);
        readonly Thread thread;
        readonly Stopwatch clock=Stopwatch.StartNew();
        long touched, serial=-1;
        int received, generation;
        double wanted, position;
        bool playing, complete, disposed;
        float gain;
        string error="", state="Preparing";
        public Playback(string endpoint,int frames) {
            if(frames<1 || frames>Rate*305)throw new ArgumentException("PLAYBACK exceeds the five-minute PCM bound.");
            pcm=new float[checked(frames*2)]; output=endpoint;
            thread=new Thread(Run) {IsBackground=true};thread.SetApartmentState(ApartmentState.STA);thread.Start();
        }
        public void AwaitReady() {
            if(!ready.WaitOne(5000))throw new TimeoutException("Native PLAYBACK output did not open.");
            lock(sync) if(error!="")throw new InvalidOperationException(error);
        }
        public void Upload(int offset,byte[] bytes) {
            lock(sync) {
                Check();
                if(complete || offset!=received || bytes==null || bytes.Length==0 || bytes.Length>262144 || bytes.Length%8!=0 ||
                    received+bytes.Length/4>pcm.Length)throw new InvalidOperationException("Invalid/sequenced PLAYBACK PCM chunk.");
                var values=new float[bytes.Length/4];Buffer.BlockCopy(bytes,0,values,0,bytes.Length);
                foreach(float v in values)if(Single.IsNaN(v)||Single.IsInfinity(v)||Math.Abs(v)>1.001f)throw new InvalidOperationException("Invalid PLAYBACK sample.");
                Array.Copy(values,0,pcm,received,values.Length);received+=values.Length;touched=clock.ElapsedMilliseconds;
            }
        }
        public void Command(long sequence,double time,bool run,double volume,bool muted,bool seek) {
            lock(sync) {
                Check();
                if(Double.IsNaN(time)||Double.IsInfinity(time)||time<0||time>pcm.Length/(2.0*Rate)+.1 ||
                    Double.IsNaN(volume)||Double.IsInfinity(volume)||volume<0||volume>1)throw new ArgumentException("Invalid PLAYBACK controls.");
                if(received!=pcm.Length)throw new InvalidOperationException("PLAYBACK PCM is incomplete.");
                if(sequence>serial) {
                    complete=true;
                    // Audio can end slightly before the video track. Heartbeats
                    // must not replay its tail; only an explicit seek rewinds it.
                    if(state=="Ended" && !seek)run=false;
                    if(seek || run!=playing) {wanted=Math.Min(time,pcm.Length/(2.0*Rate));generation++;}
                    if(seek && state=="Ended")state="Paused";
                    playing=run;gain=muted?0:(float)volume;serial=sequence;
                }
                touched=clock.ElapsedMilliseconds;
            }
        }
        void Check() { if(disposed||!thread.IsAlive||error!="")throw new InvalidOperationException(error!=""?error:"PLAYBACK closed."); }
        public object Snapshot() { lock(sync) { Check(); return new {Closed=false,State=state,Position=position,Received=received,Duration=pcm.Length/(2.0*Rate)}; } }
        void Run() {
            IDevices devices=null;IDevice device=null;object activated=null,service=null;IAudioClient2 render=null;
            IntPtr format=IntPtr.Zero,session=IntPtr.Zero;bool initialized=false,started=false;
            using(var signal=new AutoResetEvent(false)) {
                try {
                    Com.HR(Com.CoInitializeEx(IntPtr.Zero,2),"PLAYBACK COM");initialized=true;
                    if(String.IsNullOrEmpty(output)||Array.FindAll(Devices.Read(),d=>d.Flow==0&&d.Id==output).Length!=1)
                        throw new InvalidOperationException("Choose an available Audio output; no fallback.");
                    devices=(IDevices)new DeviceEnumerator();Com.HR(devices.GetDevice(output,out device),"PLAYBACK exact output");
                    Guid iid=typeof(IAudioClient2).GUID;Com.HR(device.Activate(ref iid,23,IntPtr.Zero,out activated),"PLAYBACK activate");
                    render=(IAudioClient2)activated;var properties=new ClientProperties {Size=16,Category=11};
                    Com.HR(render.SetClientProperties(ref properties),"PLAYBACK media category");
                    var bytes=new byte[18];
                    Array.Copy(BitConverter.GetBytes((ushort)3),0,bytes,0,2);Array.Copy(BitConverter.GetBytes((ushort)2),0,bytes,2,2);
                    Array.Copy(BitConverter.GetBytes(Rate),0,bytes,4,4);Array.Copy(BitConverter.GetBytes(Rate*8),0,bytes,8,4);
                    Array.Copy(BitConverter.GetBytes((ushort)8),0,bytes,12,2);Array.Copy(BitConverter.GetBytes((ushort)32),0,bytes,14,2);
                    format=Marshal.AllocCoTaskMem(18);Marshal.Copy(bytes,0,format,18);
                    session=Marshal.AllocCoTaskMem(16);Marshal.StructureToPtr(Guid.NewGuid(),session,false);
                    Com.HR(render.Initialize(0,0x880C0000,0,0,format,session),"PLAYBACK shared initialize");
                    Com.HR(render.SetEventHandle(signal.SafeWaitHandle.DangerousGetHandle()),"PLAYBACK event");
                    iid=typeof(IRender).GUID;Com.HR(render.GetService(ref iid,out service),"PLAYBACK render client");
                    var writer=(IRender)service;uint capacity;Com.HR(render.GetBufferSize(out capacity),"PLAYBACK buffer size");
                    if(capacity==0||capacity>Rate/5)throw new InvalidOperationException("PLAYBACK output latency exceeds 200ms.");
                    var mixed=new float[capacity*2];int cursor=0,seen=-1;long lastTick=clock.ElapsedMilliseconds;
                    lock(sync)state="Paused";ready.Set();
                    while(!stop.WaitOne(0)) {
                        bool run,reset;float level;int revision;
                        lock(sync) {
                            if(clock.ElapsedMilliseconds-touched>8000)throw new InvalidOperationException("PLAYBACK heartbeat expired.");
                            run=playing&&complete;level=gain;revision=generation;reset=seen!=revision;
                            if(reset){cursor=Math.Min(pcm.Length/2,(int)Math.Round(wanted*Rate));position=cursor/(double)Rate;}
                        }
                        if(reset) {
                            if(started){Com.HR(render.Stop(),"PLAYBACK pause");started=false;}
                            Com.HR(render.Reset(),"PLAYBACK seek reset");seen=revision;
                        }
                        if(run) {
                            uint padding;Com.HR(render.GetCurrentPadding(out padding),"PLAYBACK padding");
                            if(padding>capacity)throw new InvalidOperationException("Invalid PLAYBACK padding.");
                            lock(sync) { if(generation==seen)position=Math.Max(0,cursor-(int)padding)/(double)Rate; }
                            int count=Math.Min((int)(capacity-padding),pcm.Length/2-cursor);
                            if(count>0) {
                                for(int i=0;i<count*2;i++)mixed[i]=pcm[cursor*2+i]*level;
                                IntPtr buffer;Com.HR(writer.GetBuffer((uint)count,out buffer),"PLAYBACK buffer");
                                Marshal.Copy(mixed,0,buffer,count*2);Com.HR(writer.ReleaseBuffer((uint)count,0),"PLAYBACK submit");
                                cursor+=count;
                                if(!started){Com.HR(render.Start(),"PLAYBACK start");started=true;}
                                lastTick=clock.ElapsedMilliseconds;
                            } else if(cursor==pcm.Length/2 && padding==0) {
                                if(started){Com.HR(render.Stop(),"PLAYBACK end");started=false;}
                                lock(sync){if(generation==seen){playing=false;state="Ended";position=pcm.Length/(2.0*Rate);}}
                            } else if(clock.ElapsedMilliseconds-lastTick>1000)throw new InvalidOperationException("PLAYBACK output stalled.");
                            lock(sync)if(playing)state="Playing";
                        } else {lock(sync)if(state!="Ended")state="Paused";lastTick=clock.ElapsedMilliseconds;}
                        WaitHandle.WaitAny(new WaitHandle[]{stop,signal},20);
                    }
                } catch(Exception e) {lock(sync){error=e.Message;state="Error";}}
                finally {
                    if(started&&render!=null)render.Stop();
                    Com.Release(service);Com.Release(activated);Com.Release(device);Com.Release(devices);
                    if(format!=IntPtr.Zero)Marshal.FreeCoTaskMem(format);if(session!=IntPtr.Zero)Marshal.FreeCoTaskMem(session);
                    if(initialized)Com.CoUninitialize();lock(sync)pcm=null;ready.Set();
                }
            }
        }
        public void Dispose() {
            if(disposed)return;stop.Set();
            if(!thread.Join(5000))throw new TimeoutException("PLAYBACK close unacknowledged; LIVE remains locked.");
            disposed=true;stop.Dispose();ready.Dispose();
        }
    }
    public sealed partial class Controller {
        Playback playback;string playbackLease;
        readonly HashSet<string> playbackRevoked=new HashSet<string>();
        public Func<string,string,Dictionary<string,object>,byte[],object> PlaybackHandler {get{return HandlePlayback;}}
        static string Text(Dictionary<string,object> body,string key) {object v;return body.TryGetValue(key,out v)?Convert.ToString(v):"";}
        public object HandlePlayback(string action,string lease,Dictionary<string,object> body,byte[] bytes) {
            lock(gate) {
                Guid parsed;if(!Guid.TryParseExact(lease,"N",out parsed))throw new ArgumentException("Invalid PLAYBACK lease.");
                if(action=="chunk") {
                    if(lease!=playbackLease||playback==null)throw new InvalidOperationException("No PLAYBACK upload owner.");
                    playback.Upload(Int32.Parse(Text(body,"offset")),bytes);return playback.Snapshot();
                }
                if(String.IsNullOrEmpty(page)||Text(body,"page")!=page)throw new InvalidOperationException("Stale PLAYBACK page.");
                if(action=="stop") {
                    if(playbackRevoked.Count>=10000)throw new InvalidOperationException("Reload to renew PLAYBACK ownership.");
                    playbackRevoked.Add(lease);if(lease==playbackLease)StopPlayback();return new {Closed=true};
                }
                if(playbackRevoked.Contains(lease))throw new InvalidOperationException("PLAYBACK lease revoked.");
                if(action=="start") {
                    if(monitor!=null||owner!=null||playback!=null)throw new InvalidOperationException("Another audio owner is active.");
                    playbackLease=lease;
                    playback=new Playback(Text(body,"output"),Int32.Parse(Text(body,"frames")));
                    try{playback.AwaitReady();}catch{StopPlayback();throw;}
                } else {
                    if(playback==null||playbackLease!=lease)throw new InvalidOperationException("No PLAYBACK owner.");
                    if(action!="sync")throw new InvalidOperationException("Unknown PLAYBACK command.");
                    playback.Command(Int64.Parse(Text(body,"serial")),Double.Parse(Text(body,"time"),System.Globalization.CultureInfo.InvariantCulture),
                        Boolean.Parse(Text(body,"playing")),Double.Parse(Text(body,"volume"),System.Globalization.CultureInfo.InvariantCulture),
                        Boolean.Parse(Text(body,"muted")),Boolean.Parse(Text(body,"seek")));
                }
                return playback.Snapshot();
            }
        }
        void StopPlayback(){if(playback!=null){playback.Dispose();playback=null;}playbackLease=null;}
    }
    [StructLayout(LayoutKind.Sequential)] struct PropertyKey { public Guid Format; public uint Id; }
    [StructLayout(LayoutKind.Explicit,Size=24)] struct Variant { [FieldOffset(0)] public ushort Type; [FieldOffset(8)] public IntPtr Pointer; }
    [StructLayout(LayoutKind.Sequential)] struct ClientProperties { public uint Size; public int Offload,Category; public uint Options; }
    [ComImport,Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] class DeviceEnumerator { }
    [ComImport,Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IDevices {
        [PreserveSig] int EnumAudioEndpoints(int flow,uint state,out ICollection devices);
        [PreserveSig] int ReservedDefault(int flow,int role,out IDevice device);
        [PreserveSig] int GetDevice([MarshalAs(UnmanagedType.LPWStr)] string id,out IDevice device);
    }
    [ComImport,Guid("0BD7A1BE-7A1A-44DB-8397-CC5392387B5E"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface ICollection {
        [PreserveSig] int GetCount(out uint count); [PreserveSig] int Item(uint index,out IDevice device);
    }
    [ComImport,Guid("D666063F-1587-4E43-81F1-B948E807363F"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IDevice {
        [PreserveSig] int Activate(ref Guid iid,uint context,IntPtr parameters,[MarshalAs(UnmanagedType.IUnknown)] out object value);
        [PreserveSig] int OpenPropertyStore(uint access,out IProperties store);
        [PreserveSig] int GetId([MarshalAs(UnmanagedType.LPWStr)] out string id);
    }
    [ComImport,Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IProperties {
        [PreserveSig] int GetCount(out uint count); [PreserveSig] int GetAt(uint index,out PropertyKey key);
        [PreserveSig] int GetValue(ref PropertyKey key,out Variant value);
    }
    [ComImport,Guid("1CB9AD4C-DBFA-4c32-B178-C2F568A703B2"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IAudioClient {
        [PreserveSig] int Initialize(int mode,uint flags,long duration,long period,IntPtr format,IntPtr session);
        [PreserveSig] int GetBufferSize(out uint frames); [PreserveSig] int GetStreamLatency(out long hns);
        [PreserveSig] int GetCurrentPadding(out uint frames); [PreserveSig] int IsFormatSupported(int mode,IntPtr format,out IntPtr closest);
        [PreserveSig] int GetMixFormat(out IntPtr format); [PreserveSig] int GetDevicePeriod(out long normal,out long minimum);
        [PreserveSig] int Start(); [PreserveSig] int Stop(); [PreserveSig] int Reset();
        [PreserveSig] int SetEventHandle(IntPtr handle); [PreserveSig] int GetService(ref Guid iid,[MarshalAs(UnmanagedType.IUnknown)] out object service);
    }
    [ComImport,Guid("726778CD-F60A-4eda-82DE-E47610CD78AA"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IAudioClient2 {
        [PreserveSig] int Initialize(int mode,uint flags,long duration,long period,IntPtr format,IntPtr session);
        [PreserveSig] int GetBufferSize(out uint frames); [PreserveSig] int GetStreamLatency(out long hns);
        [PreserveSig] int GetCurrentPadding(out uint frames); [PreserveSig] int IsFormatSupported(int mode,IntPtr format,out IntPtr closest);
        [PreserveSig] int GetMixFormat(out IntPtr format); [PreserveSig] int GetDevicePeriod(out long normal,out long minimum);
        [PreserveSig] int Start(); [PreserveSig] int Stop(); [PreserveSig] int Reset();
        [PreserveSig] int SetEventHandle(IntPtr handle); [PreserveSig] int GetService(ref Guid iid,[MarshalAs(UnmanagedType.IUnknown)] out object service);
        [PreserveSig] int IsOffloadCapable(int category,[MarshalAs(UnmanagedType.Bool)] out bool capable);
        [PreserveSig] int SetClientProperties(ref ClientProperties properties);
    }
    [ComImport,Guid("C8ADBD64-E71E-48a0-A4DE-185C395CD317"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface ICapture {
        [PreserveSig] int GetBuffer(out IntPtr buffer,out uint frames,out uint flags,out ulong position,out ulong qpc);
        [PreserveSig] int ReleaseBuffer(uint frames); [PreserveSig] int GetNextPacketSize(out uint frames);
    }
    [ComImport,Guid("F294ACFC-3146-4483-A7BF-ADDCA7C260E2"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IRender {
        [PreserveSig] int GetBuffer(uint frames,out IntPtr buffer); [PreserveSig] int ReleaseBuffer(uint frames,uint flags);
    }
}
