// One native live-monitor lease per preview. No browser-render fallback.
(function(root){
  'use strict';
  class NativeMonitor {
    constructor(ui){
      this.ui=ui;this.lease=null;this.running=false;this.pending=false;this.error='';
      this.info=null;this.timer=null;this.queue=Promise.resolve();this.sequence=0;this.revision=0;
    }
    show(){this.ui.show(this);}
    enqueue(fn){const next=this.queue.then(fn);this.queue=next.catch(()=>{});return next;}
    async send(action,lease,body={},keepalive=false){return this.ui.request(action,{lease,serial:++this.sequence,...body},keepalive);}
    async start(){
      const revision=++this.revision;
      return this.enqueue(async()=>{
        if(revision!==this.revision || !this.ui.captureLive() || this.ui.reviewing())return;
        if(this.running)return;
        if(this.lease)await this.close(this.lease);
        const selection=this.ui.selection();
        if(!selection.input || !selection.output)throw Error('Open DEVICE and choose available audio input and output.');
        const lease=crypto.randomUUID();this.lease=lease;this.pending=true;this.error='';this.show();
        try {
          this.ui.detachBrowser();
          const result=await this.send('start',lease,{...selection,...this.ui.level()});
          if(revision!==this.revision || !this.ui.captureLive() || this.ui.reviewing()) {await this.close(lease);return;}
          if(result.Monitor?.State!=='Running')throw Error('Native monitor did not start.');
          this.info=result.Monitor;this.running=true;
          clearInterval(this.timer);this.timer=setInterval(()=>this.pulse(),2000);
        }catch(e){this.error=e.message;await this.close(lease).catch(close=>{this.error+='; '+close.message;});throw Error(this.error);}
        finally{this.pending=false;this.show();}
      }).catch(e=>{this.error=e.message;this.show();throw e;});
    }
    async close(lease,keepalive=false){
      const result=await this.send('stop',lease,{},keepalive);
      if(!result.Closed)throw Error('Native close unacknowledged; playback locked.');
      if(this.lease===lease){this.lease=null;this.running=false;}
    }
    stop(keepalive=false){
      ++this.revision;clearInterval(this.timer);this.timer=null;this.running=false;
      const lease=this.lease;
      // Immediately revoke even if start is still in flight; the host rejects
      // late starts for this lease. Queue completion also waits for prior work.
      const closing=lease?this.close(lease,keepalive):Promise.resolve();
      closing.catch(()=>{});
      return this.enqueue(async()=>{
        try{await closing;this.error='';}catch(e){this.error=e.message;throw e;}
        finally{this.pending=false;this.show();}
      });
    }
    volume(){return this.enqueue(async()=>{
      if(!this.running || !this.lease)return;
      try{await this.send('volume',this.lease,this.ui.level());}
      catch(e){this.error=e.message;this.running=false;clearInterval(this.timer);await this.close(this.lease).catch(close=>{this.error+='; '+close.message;});this.show();throw e;}
    });}
    pulse(){
      if(this.polling || !this.running)return;
      this.polling=true;
      return this.enqueue(async()=>{
        if(!this.running || !this.lease)return;
        try{
          if(!this.ui.captureLive())throw Error('Browser capture ended; native monitor stopped.');
          const result=await this.send('pulse',this.lease);
          if(result.Monitor?.State!=='Running')throw Error(result.Monitor?.Error || 'Native monitor stopped.');
          this.info=result.Monitor;
        }catch(e){this.error=e.message;this.running=false;clearInterval(this.timer);await this.close(this.lease).catch(close=>{this.error+='; '+close.message;});}
        finally{this.show();}
      }).finally(()=>{this.polling=false;});
    }
  }
  // Browser identities are origin-scoped and are never Windows endpoint IDs.
  // A unique friendly-name correspondence is required on BOTH sides; ambiguous
  // or differently named devices require correction/reselection, never guessing.
  class DeviceSelection {
    constructor(media,storage,nativeDevices){
      this.media=media;this.storage=storage;this.nativeDevices=nativeDevices;
      this.key='musx-remocon.devices.v1';this.selected=null;this.browser=[];this.native=[];
      try { const s=JSON.parse(storage.getItem(this.key));
        if(s && ['video','audio','output','nativeInput','nativeOutput'].every(k=>typeof s[k]==='string' && s[k]) &&
          ['native','compatible'].includes(s.mode))this.selected=s;
      }catch{}
    }
    physical(d){return !!d.deviceId && !['default','communications'].includes(d.deviceId);}
    async scan(){
      const [browser,native]=await Promise.all([this.media.enumerateDevices(),this.nativeDevices()]);
      this.browser=browser.filter(d=>this.physical(d));this.native=native;return this.browser;
    }
    device(kind,id){
      const matches=this.browser.filter(d=>d.kind===kind && d.deviceId===id);
      if(matches.length!==1)throw Error('Selected '+kind+' is unavailable. Open DEVICE and reselect; no fallback.');
      return matches[0];
    }
    name(label){return label.replace(/\s+\([0-9a-f]{4}:[0-9a-f]{4}\)$/i,'').trim();}
    endpoint(device,flow){
      const name=this.name(device.label || '');
      const peers=this.browser.filter(d=>d.kind===device.kind && this.name(d.label || '')===name);
      const matches=this.native.filter(d=>d.Flow===flow && this.name(d.Name || '')===name);
      if(!name || peers.length!==1 || matches.length!==1)
        throw Error('Cannot uniquely match "'+(device.label || device.kind)+'" to native audio. Check Windows device names and refresh; no fallback.');
      return matches[0].Id;
    }
    resolve(s){
      if(!s)throw Error('Open DEVICE, choose video/audio inputs and audio output, then Apply.');
      this.device('videoinput',s.video);
      const input=this.endpoint(this.device('audioinput',s.audio),1);
      const output=this.endpoint(this.device('audiooutput',s.output),0);
      if(s.nativeInput && s.nativeInput!==input || s.nativeOutput && s.nativeOutput!==output)
        throw Error('The selected native endpoint identity changed. Reselect in DEVICE; no fallback.');
      this.requireDirectFormat(s);
      return {...s,nativeInput:input,nativeOutput:output};
    }
    apply(s){this.selected=this.resolve(s);this.persist();return this.selected;}
    persist(){try{this.storage.setItem(this.key,JSON.stringify(this.selected));return true;}catch{return false;}}
    async validate(){await this.scan();return this.resolve(this.selected);}
    requireDirectFormat(s){
      // Product intent: preserve 4:3 and keep MOVIE at the canonical 640x480.
      // The current recorder consumes capture directly. Merely letterboxing
      // its preview cannot normalize larger recordings, so do not accept them.
      if(s?.mode==='compatible')throw Error('Compatible normalization is unavailable: other capture sizes need a verified 4:3 / 640×480 recording path. Choose Direct 4:3 in DEVICE.');
      if(s?.mode!=='native')throw Error('Choose Direct 4:3 in DEVICE.');
    }
    constraints(s){
      this.requireDirectFormat(s);
      const video={deviceId:{exact:s.video},width:{exact:640},height:{exact:480}};
      if(!this.media.getSupportedConstraints().resizeMode)throw Error('Direct 4:3 requires browser resizeMode support; safe normalization is unavailable.');
      video.resizeMode={exact:'none'};
      return {video,audio:{deviceId:{exact:s.audio},echoCancellation:{exact:false},noiseSuppression:{exact:false},autoGainControl:{exact:false}}};
    }
    verify(stream,s){
      this.requireDirectFormat(s);
      const vs=stream.getVideoTracks(),as=stream.getAudioTracks(),v=vs[0],a=as[0];
      const video=v?.getSettings() || {},audio=a?.getSettings() || {};
      if(vs.length!==1 || as.length!==1 || v.readyState!=='live' || a.readyState!=='live' ||
        video.deviceId!==s.video || audio.deviceId!==s.audio ||
        !Number.isInteger(video.width) || !Number.isInteger(video.height) || video.width<=0 || video.height<=0 ||
        ['echoCancellation','noiseSuppression','autoGainControl'].some(k=>audio[k]!==false))
        throw Error('Capture identity, resolution or processing-off verification failed; capture stopped.');
      if(video.width!==640 || video.height!==480 || video.resizeMode!=='none')
        throw Error('Direct 4:3 capture/recording at 640×480 could not be established. Other sizes require safe normalization, which is unavailable.');
      return video;
    }
  }
  NativeMonitor.DeviceSelection=DeviceSelection;
  root.RemoconDeviceSelection=DeviceSelection;
  if(typeof module!=='undefined')module.exports=NativeMonitor;
  root.RemoconNativeMonitor=NativeMonitor;
})(typeof window!=='undefined'?window:globalThis);
