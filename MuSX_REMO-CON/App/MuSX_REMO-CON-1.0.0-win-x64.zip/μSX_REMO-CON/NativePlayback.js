// Offline decode only: never connect MOVIE audio to a browser output.
(function(root){
'use strict';
class NativePlayback {
  constructor(ui){this.ui=ui;this.session=null;this.serial=0;this.closing=null;}
  async request(s,action,body={},bytes,offset,keepalive=false){
    const abort=new AbortController();s.requests.add(abort);
    const timer=setTimeout(()=>abort.abort(),9000);
    try{
      const response=await fetch(this.ui.origin+'/movie/'+this.ui.token+'/audio/'+action+'/'+s.lease+
        (offset===undefined?'':'/'+offset),{method:'POST',mode:'cors',cache:'no-store',keepalive,signal:abort.signal,
        headers:{'Content-Type':bytes?'application/octet-stream':'application/json'},
        body:bytes || JSON.stringify({page:this.ui.page,...body})});
      const result=await response.json();if(!response.ok)throw Error(result.error || 'Native PLAYBACK request failed.');
      return result;
    }finally{clearTimeout(timer);s.requests.delete(abort);}
  }
  valid(s){if(this.session!==s || s.stopped)throw Error('PLAYBACK cancelled.');}
  async readMovie(s,url,movie){
    const size=movie.bytes,part=4*1024*1024;
    if(!Number.isSafeInteger(size)||size<1||size>512*1024*1024)throw Error('MOVIE exceeds the encoded size bound.');
    const encoded=new Uint8Array(size);
    // The worker deliberately bounds each request, not an entire long MOVIE.
    // Reassemble finite ranges before offline decode; never retry a whole clip.
    for(let first=0;first<size;first+=part){
      const last=Math.min(size-1,first+part-1);
      for(let attempt=0;;attempt++){
        this.valid(s);
        const abort=new AbortController();s.requests.add(abort);
        const timer=setTimeout(()=>abort.abort(),9000);
        try{
          const response=await fetch(url,{mode:'cors',cache:'no-store',signal:abort.signal,headers:{Range:'bytes='+first+'-'+last}});
          if(response.status!==206)throw Object.assign(Error('MOVIE range refused (HTTP '+response.status+').'),{noRetry:true});
          if(response.headers.get('Content-Range')!=='bytes '+first+'-'+last+'/'+size || Number(response.headers.get('Content-Length'))!==last-first+1)
            throw Object.assign(Error('MOVIE range identity/length mismatch.'),{noRetry:true});
          const chunk=await response.arrayBuffer();
          this.valid(s);
          if(chunk.byteLength!==last-first+1)throw Error('Incomplete MOVIE range.');
          encoded.set(new Uint8Array(chunk),first);break;
        }catch(e){
          this.valid(s);
          if(e.noRetry||attempt>=1)throw Error('MOVIE download bytes '+first+'-'+last+': '+e.message);
        }finally{clearTimeout(timer);abort.abort();s.requests.delete(abort);}
      }
    }
    return encoded.buffer;
  }
  async prepare(url,movie){
    if(this.preparing)throw Error('Previous PLAYBACK decoder is still finishing; retry Play shortly.');
    if(this.closing)await this.closing;
    if(this.session)throw Error('PLAYBACK already owned.');
    const output=this.ui.output();if(!output)throw Error('Choose Audio output before Play.');
    const s={lease:crypto.randomUUID().replaceAll('-',''),requests:new Set(),stopped:false,opened:false,handlers:[]};
    this.session=s;
    this.preparing=true;
    let stage='MOVIE download';
    try{
      let encoded=await this.readMovie(s,url,movie);
      this.valid(s);
      stage='Offline audio decode';
      if(!root.OfflineAudioContext)throw Error('Offline MOVIE decoding unavailable; no browser audio fallback.');
      const decoder=new root.OfflineAudioContext(2,1,48000);
      const audio=await decoder.decodeAudioData(encoded);encoded=null;
      this.valid(s);
      if(audio.sampleRate!==48000||audio.numberOfChannels<1||audio.numberOfChannels>2||audio.length<1||audio.duration>305)
        throw Error('Unsupported MOVIE audio layout/duration.');
      s.duration=audio.duration;
      stage='Native output start';
      s.opened=true;await this.request(s,'start',{output,frames:audio.length,movie:movie.id});
      this.valid(s);
      stage='Native PCM upload';
      const left=audio.getChannelData(0),right=audio.getChannelData(Math.min(1,audio.numberOfChannels-1));
      for(let frame=0;frame<audio.length;frame+=32768){
        this.valid(s);const count=Math.min(32768,audio.length-frame),pcm=new Float32Array(count*2);
        for(let i=0;i<count;i++){pcm[i*2]=Math.max(-1,Math.min(1,left[frame+i]));pcm[i*2+1]=Math.max(-1,Math.min(1,right[frame+i]));}
        await this.request(s,'chunk',{},pcm.buffer,frame*2);
      }
      this.valid(s);
      const video=this.ui.video;
      const listen=(name,fn)=>{video.addEventListener(name,fn);s.handlers.push([name,fn]);};
      listen('volumechange',()=>{if(!video.muted)video.muted=true;});
      listen('seeking',()=>{if(!s.correcting)s.seek=true;this.tick(s);});
      listen('seeked',()=>this.tick(s));
      listen('playing',()=>{s.buffering=false;this.tick(s);});
      listen('waiting',()=>{s.buffering=true;this.tick(s);});
      listen('pause',()=>this.tick(s));
      listen('ratechange',()=>{if(![.98,1,1.02].includes(video.playbackRate)){video.playbackRate=1;s.seek=true;this.tick(s);}});
      video.muted=true;video.defaultMuted=true;
      await this.sync(s,true,false);
      s.timer=setInterval(()=>this.tick(s),200);
    }catch(e){e.message=stage+': '+e.message;if(this.session===s)await this.stop().catch(close=>{e.message+='; '+close.message;});throw e;}
    finally{this.preparing=false;}
  }
  async sync(s,seek=false,playing){
    const video=this.ui.video;
    const time=Math.max(0,Math.min(s.duration,Number(video.currentTime)||0));
    const run=playing===undefined?!video.paused&&!video.seeking&&!video.ended&&!s.buffering:playing;
    const result=await this.request(s,'sync',{serial:++this.serial,time,playing:run,seek,...this.ui.level()});
    this.valid(s);
    if(run && !seek && !s.seek && !video.seeking && result.State==='Playing'){
      const drift=result.Position-video.currentTime;
      if(Math.abs(drift)>.18){
        s.correcting=true;video.currentTime=result.Position;
        // seek events are queued by the browser; ignore our own correction until seeked.
        const done=()=>{s.correcting=false;video.removeEventListener('seeked',done);};
        video.addEventListener('seeked',done);s.handlers.push(['seeked',done]);
      }else{
        s.adjusting=true;video.playbackRate=Math.abs(drift)<.025?1:drift>0?1.02:.98;
        s.adjusting=false;
      }
    }
    return result;
  }
  tick(s=this.session){
    if(!s||s.stopped||s.busy)return;
    s.busy=true;const seek=!!s.seek;s.seek=false;
    return this.sync(s,seek).catch(e=>{if(this.session===s&&!s.stopped)this.ui.fail(e);}).finally(()=>{s.busy=false;});
  }
  stop(keepalive=false){
    const s=this.session;if(!s)return this.closing || Promise.resolve();
    if(s.stopped && this.closing)return this.closing;
    s.stopped=true;clearInterval(s.timer);
    for(const [name,fn] of s.handlers)this.ui.video.removeEventListener(name,fn);
    for(const request of s.requests)request.abort();
    this.ui.video.muted=true;this.ui.video.playbackRate=1;
    // Revoke even if native start is still in flight. Do not allow LIVE until acknowledged.
    const close=s.opened?this.request(s,'stop',{},undefined,undefined,keepalive).then(r=>{if(!r.Closed)throw Error('PLAYBACK close unacknowledged.');}):Promise.resolve();
    const pending=close.then(()=>{if(this.session===s)this.session=null;this.closing=null;});
    this.closing=pending;
    pending.catch(()=>{if(this.closing===pending)this.closing=null;});
    return this.closing;
  }
}
root.RemoconNativePlayback=NativePlayback;
if(typeof module!=='undefined')module.exports=NativePlayback;
})(typeof window==='undefined'?globalThis:window);
