# μSX REMO-CON Ver.1.0.0 — for Windows 11 x64

μSX REMO-CON is a Windows application for viewing the VGA output and hearing the audio of a real μSX on a PC while operating it from the PC through keyboard and input functions. It brings LIVE display, input, CLIP and TAPE functions together in one interface so the real μSX can be handled conveniently from the PC.

As an additional integration feature, REMO-CON also supports file transfer via ESERAMair.

This is a free DIY hobby project.

## AI-developed project

REMO-CON-specific software was **implemented, tested, and documented through a 100% AI-driven development process using ChatGPT and Codex**.

In contrast, the hardware and firmware for IOEμ are **created entirely by hand (100% human-made)**.

日本語版: [README_ja.md](README_ja.md)

## Requirements and scope

- Windows 11 x64. Ver.1.0.0 is Windows-only; macOS and Linux are not supported.
- Microsoft Edge WebView2 Evergreen Runtime for the primary application.
- Appropriate capture/audio/serial drivers, connected hardware, and access permissions for the functions you use.
- A writable local folder. Extract the complete ZIP to a folder before running the application; do not run it directly from inside the ZIP archive.

For VGA/audio monitoring, REMO-CON currently requires a compatible **640×480, 4:3** capture path. Missing or ambiguous devices fail visibly instead of causing automatic selection of another device.

Ver.1.0.0 was tested on real μSX hardware using a **ATCCPYDM VGA to USB 3.0 capture board (model: V2U-LO)** at **640×480, 4:3**. This device supports **UVC (USB Video Class) / UAC (USB Audio Class)** and uses standard Windows drivers, so a dedicated driver installation is normally unnecessary.

Tested DEVICE examples (Japanese Windows):

- **VIDEO INPUT:** `AFN_cap video (0001:afa1)`
- **AUDIO INPUT:** `デジタル オーディオ インターフェイス (USB3 Digital Audio) (0001:afa1)`

VIDEO INPUT / AUDIO INPUT display names depend primarily on the capture device being used. Select the video and audio inputs corresponding to your connected capture device.

Other devices recognized by Windows / WebView2 as standard video and audio inputs may also be candidates, but operation with other models is not guaranteed.

Feature-specific hardware/environment requirements are:

- **KeyScan / text input:** KeyScan-Emu and its serial connection.
- **TAPE:** the **X-Converter board from the μSX OptionBoard** and an **M5Stack AtomU** are required to connect μSX and the PC for TAPE operations. The AtomU must contain the firmware used by the CAS-IF TAPE interface. That firmware is included in the **CAS-IF Tape Backup Ver.1.0.0 release package**; it is not included in the REMO-CON ZIP.
- **ESERAMair:** a compatible ESERAMair environment reachable from the PC at `eseram.local:8080`.

X-Converter / μSX OptionBoard information:

[μSX OptionBoard README](https://github.com/KickState/IOEmu_for_MSX/blob/main/MuSX_OptionBoard/readme_musx_optionboard.md)

## Start and close the primary application

1. **No installer is required.** Extract the complete ZIP to a writable local folder, preserving the folder structure.
2. Launch **μSX_REMO-CON.exe**.
3. If WebView2 Runtime is missing, install Evergreen Runtime from [Microsoft's download page](https://developer.microsoft.com/en-us/microsoft-edge/webview2/) and reopen the app. REMO-CON does not install it automatically, and the Runtime itself is not bundled.

The dedicated window opens within the working area of the monitor containing the pointer. Initial DPI-aware fitting uses 65–100% zoom for the closed-settings view, once per launch. You can resize normally or use Ctrl+mouse-wheel afterward. Small screens and open settings panels may require scrolling. VGA retains its 4:3 geometry.

Use one REMO-CON instance at a time. The application uses the local address `127.0.0.1:8780`. Stop CLIP recording and TAPE activity before closing the dedicated window, then wait for shutdown before moving the folder or disconnecting hardware.

## Basic operation — DEVICE setup

1. Connect μSX video/audio to compatible capture inputs and connect speakers or headphones.
2. Open the DEVICE gear and click **Refresh**. Approve camera/microphone access if prompted.
3. Temporary permission-check streams stop, then all device lists refresh automatically. Already-permitted profiles simply re-enumerate.
4. Explicitly select **VIDEO INPUT**, **AUDIO INPUT**, and **AUDIO OUTPUT**, then click **Apply**. There is no automatic device selection or automatic Apply.

If permission is denied, follow the displayed Windows/site-permission guidance and retry Refresh. If a permitted device is missing, check its connection and driver. Selection settings belong to the current application profile.

## LIVE — VGA + AUDIO

Click **Start LIVE** to preview and **Stop LIVE** to stop. The opening-progress message clears when startup completes.

Mute/Volume controls monitoring and playback, not the recording source. Audio uses the explicitly selected output.

## INPUT — KeyScan-Emu keyboard and text input

Connect KeyScan-Emu, refresh **KeyScan PORT**, select its port explicitly, and click **Connect**.

### Direct Keyboard

Focus the VGA area to send keyboard input directly.

### Line Input

Type or paste one line and press Enter to send it. No carriage return is appended automatically.

### File Input

Click ＋ to choose a text file, or simply **drop a text file onto the Line Input area**. File Input sends the text line by line. The transfer Stop control stops the remaining send.

### Send delay

The settings gear provides independent Line Input and File Input delays. Defaults are **0 / 42 ms per character**; each accepts an integer from 0 to 250. Apply saves, Init resets the draft values, and Close discards uncommitted edits. These settings do not delay Direct Keyboard.

Choose delays appropriate for the receiving program. Input is restricted during states such as CLIP review.

## CLIP

With LIVE available, use ● to record, ■ to stop, and ▶ to review the latest successfully completed clip. A clip can be up to five minutes; data-size limits and save failures are reported. Wait for finalization after stopping before exiting.

Review switches audio ownership so LIVE and playback do not compete. During review, use the video's playback controls to pause/resume or seek to another position. Use ■ to end review. Ending/stopping review returns to the normal state. Recordings and completion metadata are stored in `MOVIE_DATA`. CLIP is not a general video-library manager.

## TAPE — Direct LOAD / SAVE

**TAPE requires both the μSX OptionBoard X-Converter board and an M5Stack AtomU.** See the [μSX OptionBoard README](https://github.com/KickState/IOEmu_for_MSX/blob/main/MuSX_OptionBoard/readme_musx_optionboard.md) for X-Converter information and connection details.

The required AtomU firmware is included in the **CAS-IF Tape Backup Ver.1.0.0 release package**. REMO-CON itself does not install or update the AtomU firmware.

Connect the TAPE hardware, refresh **AtomU PORT**, and explicitly select the intended serial port.

- **LOAD into μSX (Direct Playback):** click ＋ or **drop one `.casraw` / `.casraw.zip` file onto the TAPE file area**. Prepare μSX for the corresponding LOAD/BLOAD operation, then press ▶. Playback begins automatically after preparation; no second click is required.
- **SAVE from μSX:** optionally enter a REC name, press ●, and send the save data from μSX. Press ■ to stop and wait for the completed recording. Capture uses 38,400 samples/s.

Output is saved in `TAPE_DATA`. Protect existing recordings; do not disconnect the interface or forcibly terminate the app during an operation.

The bundled `tape_cmd/playback.exe` and `tape_cmd/capture.exe` helpers are required for TAPE. Keep that folder and its license/notices intact. A separate Python installation is not needed. The helpers temporarily extract runtime files while they are running; do not delete those files during an operation.

## ESERAMair transfer

ESERAMair transfer is an additional convenience feature for a compatible ESERAMair environment.

For a compatible ESERAMair, the PC must be able to reach `eseram.local:8080` on the appropriate network.

**Drop one file directly onto the VGA screen.** The screen highlights with `DROP FILE TO μSX`, and REMO-CON transfers the file through ESERAMair.

This drop target is separate from the Line Input text-file target and the TAPE target. Verify the destination and network before use.

## Microsoft Edge fallback

Close the dedicated app, then run **Start-RemoConDisplay.cmd**. It explicitly opens Microsoft Edge in a separate normal window, without using or changing your default browser. Chrome, Firefox, and other browsers are not supported fallback targets.

**Closing Edge alone does not stop the fallback host.** Run Start CMD again to reopen Edge using this folder's own healthy running host. It does not attach to an unrelated or unverified listener.

To fully stop the fallback host, stop active operations and run **Stop-RemoConDisplay.cmd**. Unrelated Edge windows are not closed. Edge and the dedicated app use separate profiles, device settings, and permissions.

## Data and updates

- `MOVIE_DATA`: CLIP recordings and completion metadata.
- `TAPE_DATA`: TAPE recordings.
- `state/webview2`: dedicated-app profile created/used at runtime; do not delete it while the app is running.

Reopening the same folder with the dedicated WebView2 app preserves its settings; a fresh extraction uses a separate `state/webview2` profile. The Edge fallback uses your normal Edge profile, so settings and permissions for the same local address may be shared across extracted copies. Close normally and back up needed recordings/settings before replacing or moving the application.

## Release-package contents

The release package contains the primary application, its runtime inputs, WebView2 SDK files, TAPE helpers, notices, and empty data folders:

```text
μSX_REMO-CON/
  μSX_REMO-CON.exe
  index.html
  Movie.js
  NativeMonitor.js
  NativePlayback.js
  MovieWorker.cs
  NativeMonitor.cs
  Start-RemoConDisplay.cmd
  Start-RemoConDisplay.ps1
  Stop-RemoConDisplay.cmd
  Stop-RemoConDisplay.ps1
  Microsoft.Web.WebView2.Core.dll
  Microsoft.Web.WebView2.WinForms.dll
  WebView2Loader.dll
  tape_cmd/
  notices/
  MOVIE_DATA/
  TAPE_DATA/
  README.md
  README_ja.md
  LICENSE
  THIRD_PARTY_NOTICES.md
  release-manifest.json
```

Keep the package structure intact. The two C# files above are runtime inputs compiled by the host at startup; they are not development leftovers.

## Troubleshooting

- **Cannot launch:** confirm complete extraction, a writable folder, and WebView2 Evergreen Runtime.
- **Address in use:** close another REMO-CON instance normally. Use Stop CMD to fully stop this folder's fallback host. Do not delete an active ownership record.
- **An older fallback host cannot be reused:** stop it normally once with Stop CMD, then run Start CMD.
- **No video/audio:** check DEVICE permissions, all three selections, wiring, and the supported capture format.
- **KeyScan/text input fails:** check KeyScan PORT selection, connection state, and whether another application holds the port.
- **ESERAMair transfer fails:** confirm the ESERAMair network and that `eseram.local:8080` is reachable from the PC.
- **TAPE operation fails:** confirm the X-Converter/AtomU connection, required AtomU firmware, AtomU PORT selection, driver availability, and whether another application holds the port.

## Licensing

See [LICENSE](LICENSE) for the terms covering KickState-authored material and [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) for bundled third-party components.
