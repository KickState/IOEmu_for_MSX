# μSX REMO-CON Ver.1.0.0 — Windows 11 x64版

μSX REMO-CON は、実機 μSX の VGA 画面と音声を PC 上で確認しながら、キーボード入力などを PC から操作するための Windows アプリケーションです。LIVE 表示、入力、CLIP、TAPE などを一つの画面にまとめ、実機 μSX を PC から扱いやすくすることを目的としています。

さらに、外部機器との連携機能として、ESERAMairによるファイル転送にも対応しています。

本ソフトウェアは、無償公開の DIY 趣味プロジェクトです。

## AIによる開発について

REMO-CON固有のソフトウェアは、**ChatGPT と Codex による100% AI駆動の開発プロセスで実装・検証・文書作成されています**。

一方、IOEμのハードウェアとfirmwareは、**人力100%**で作成されています。

English version: [README.md](README.md)

## 動作環境と必要なもの

- Windows 11 x64。Ver.1.0.0 は Windows 専用です。macOS / Linux は対象外です。
- 通常起動用の Microsoft Edge WebView2 Evergreen Runtime。
- 使用する機能に応じたキャプチャ・音声・シリアル機器、ドライバー、アクセス権。
- 書き込み可能なローカルフォルダー。公開 ZIP はフォルダーへ完全に展開してから使用し、ZIP 内から直接実行しないでください。

VGA・音声の LIVE 表示では、現在 **640×480、4:3** の対応キャプチャ経路を使用します。機器が見つからない場合や識別が曖昧な場合、別の機器を自動選択せずエラーを表示します。

Ver.1.0.0 の実機検証では、**ATCCPYDM製 VGA to USB 3.0 キャプチャーボード（型番：V2U-LO）**を使用し、**640×480・4:3**で動作を確認しました。この機器は **UVC (USB Video Class) / UAC (USB Audio Class)** に対応し、Windows 標準ドライバーで認識されるため、通常は専用ドライバーのインストールは不要です。

実機検証時の DEVICE 表示例:

- **VIDEO INPUT:** `AFN_cap video (0001:afa1)`
- **AUDIO INPUT:** `デジタル オーディオ インターフェイス (USB3 Digital Audio) (0001:afa1)`

VIDEO INPUT / AUDIO INPUT の表示名は、主に使用するキャプチャ機器によって異なります。接続しているキャプチャ機器に対応する映像入力・音声入力を選択してください。

他の機器でも、Windows / WebView2 から通常の映像入力・音声入力として認識されるものは利用候補になりますが、他機種での動作を保証するものではありません。

機能ごとの追加条件は次のとおりです。

- **KeyScan / テキスト入力:** KeyScan-Emu とシリアル接続が必要です。
- **TAPE:** μSX と PC を接続するため、**μSX OptionBoard の X-Converter 基板**と **M5Stack AtomU** が必要です。AtomU には CAS-IF TAPE インターフェース用のファームウェアが必要です。このファームウェアは **CAS-IF Tape Backup Ver.1.0.0 のリリースパッケージに含まれています**。REMO-CON の ZIP には含まれていません。
- **ESERAMair:** PC から `eseram.local:8080` に到達できる対応 ESERAMair 環境が必要です。

X-Converter / μSX OptionBoard の詳細:

[μSX OptionBoard README](https://github.com/KickState/IOEmu_for_MSX/blob/main/MuSX_OptionBoard/readme_musx_optionboard.md)

## 起動と終了

1. **インストーラーは不要です。** ZIP 全体をローカルの書き込み可能なフォルダーへ展開し、ファイルとサブフォルダーの構成を保ちます。
2. **μSX_REMO-CON.exe** を起動します。
3. WebView2 Runtime がない場合は、[Microsoft の配布ページ](https://developer.microsoft.com/en-us/microsoft-edge/webview2/)から Evergreen Runtime を導入して再起動してください。本アプリが自動インストールすることはありません。Runtime 自体は同梱していません。

専用ウィンドウはポインターのある画面の作業領域と DPI に合わせて開き、設定パネルを閉じた状態を初期表示時に一度だけ 65～100% の範囲で調整します。その後は通常のサイズ変更や Ctrl+マウスホイールを使用できます。小さい画面や設定パネルではスクロールが必要な場合があります。映像の 4:3 比率は維持されます。

同時に使う REMO-CON は一つにしてください。ローカル通信に `127.0.0.1:8780` を使用します。終了前に CLIP 録画や TAPE 操作を停止し、専用ウィンドウを閉じて終了処理を待ってください。

## 基本操作 — DEVICE の設定

1. μSX の映像・音声を対応するキャプチャ機器に接続し、スピーカーまたはヘッドホンを用意します。
2. DEVICE の歯車を開いて **Refresh** を押します。初回などアクセスが必要な場合は、カメラとマイクの許可に応答してください。
3. 許可確認に使った一時ストリームは停止され、一覧が自動更新されます。許可済みの場合は再列挙します。
4. **VIDEO INPUT / AUDIO INPUT / AUDIO OUTPUT** を明示的に選び、**Apply** を押します。機器の自動選択や自動 Apply は行いません。

許可を拒否した場合は、表示された案内に従って Windows またはサイトのカメラ・マイク権限を確認し、Refresh を再試行してください。許可後も機器がない場合は接続とドライバーを確認します。

## LIVE — VGA と音声

**Start LIVE** で確認を開始し、**Stop LIVE** で停止します。起動中の Opening 表示は完了すると消えます。

音量・ミュートはモニターと再生に作用し、録音元の音量を書き換えるものではありません。音声出力は選択した出力機器を使用します。

## INPUT — KeyScan-Emu による入力

KeyScan-Emu を接続し、**KeyScan PORT** を更新して対象ポートを明示的に選び、**Connect** を押します。

### Direct Keyboard

VGA 画面にフォーカスしてキーボード入力を直接送ります。

### Line Input

1行の文字列を入力または貼り付け、Enter で送信します。自動で行末の CR を追加しません。

### File Input

＋ でテキストファイルを選ぶか、**テキストファイルをそのまま Line Input 欄へドロップ**します。File Input は行単位でテキストを送信します。送信中の Stop で残りの送信を止められます。

### Send delay

設定の歯車から Line Input と File Input の遅延を個別設定できます。初期値は **0 / 42 ms/char**、設定範囲は整数の 0～250 です。Apply で保存、Init で編集中の値を初期値に戻し、Close で未保存の変更を破棄します。Direct Keyboard にはこの遅延設定を適用しません。

受信側の処理速度に合わせて遅延を調整してください。CLIP 再生中など操作できない状態では送信が制限されます。

## CLIP

LIVE の映像・音声を短いクリップとして録画します。● で録画開始、■ で停止、▶ で最後に正常完了したクリップを再生します。録画上限は 5 分です。停止後は完了処理を待ってから終了してください。長さやデータ量の制限、保存エラーは表示されます。

再生中は LIVE 音声と競合しないように切り替わります。映像の再生コントロールで一時停止・再開やシーク（再生位置の移動）ができます。■ で再生確認を終了します。再生を停止・終了すると通常の状態に戻ります。録画と完了情報は `MOVIE_DATA` に保存されます。アプリは汎用的な動画ライブラリー管理ソフトではありません。

## TAPE — Direct LOAD / SAVE

**TAPE機能には、μSX OptionBoard の X-Converter 基板と M5Stack AtomU の両方が必要です。** X-Converter の詳細・接続については [μSX OptionBoard README](https://github.com/KickState/IOEmu_for_MSX/blob/main/MuSX_OptionBoard/readme_musx_optionboard.md) を参照してください。

AtomU に必要なファームウェアは、**CAS-IF Tape Backup Ver.1.0.0 のリリースパッケージに含まれています**。REMO-CON 自体は AtomU のファームウェアを同梱・更新しません。

TAPE の接続を行い、**AtomU PORT** を更新して対象のシリアルポートを明示的に選びます。

- **μSX へ LOAD（Direct Playback）:** ＋ を押すか、**`.casraw` / `.casraw.zip` を TAPE のファイル欄へドロップ**し、μSX 側を対応する LOAD/BLOAD の受信待ち状態にしてから ▶ を押します。準備完了後は自動で再生を開始するため、二度目のクリックは不要です。
- **μSX から SAVE:** 必要なら REC 名を入力して ● を押し、μSX 側から保存データを送ります。■ で停止し、保存完了を待ちます。キャプチャは 38,400 samples/s を使用します。

TAPE の出力は `TAPE_DATA` に保存されます。既存の録音やテープデータを保護し、処理中にケーブルを抜いたりアプリを強制終了したりしないでください。

`tape_cmd/playback.exe` と `tape_cmd/capture.exe` は TAPE に必要な同梱ヘルパーです。フォルダーごと維持してください。Python の別途インストールは不要です。ヘルパーは実行時に一時ファイルを展開するため、動作中の一時ファイルを削除しないでください。同梱のライセンスと第三者通知も維持してください。

## ESERAMair ファイル転送

ESERAMair に対応した環境向けの追加機能として、ファイル転送も利用できます。

対応する ESERAMair を使う場合、PC から適切なネットワーク上の `eseram.local:8080` に到達できる必要があります。

**転送したいファイルを一つ、VGA画面へそのままドロップしてください。** 画面がハイライトされ、`DROP FILE TO μSX` と表示されて、ESERAMair 経由で転送します。

VGA画面へのドロップは、Line Input のテキスト File Input や TAPE のドロップとは別の機能です。転送先やネットワーク設定を確認してから使用してください。

## Microsoft Edge による代替起動

専用アプリを閉じてから **Start-RemoConDisplay.cmd** を実行すると、Microsoft Edge の独立した通常ウィンドウが開きます。既定のブラウザーは使用・変更しません。Chrome / Firefox などは代替起動の対応対象ではありません。

**Edge を閉じただけではバックグラウンドのホストは停止しません。** 同じフォルダーの正常なホストが残っていれば、Start CMD を再実行して Edge を開き直せます。所有を確認できない別のプロセスには接続しません。

完全に終了するには操作を停止し、**Stop-RemoConDisplay.cmd** を実行します。無関係な Edge ウィンドウは終了させません。Edge と専用アプリの機器設定・権限は別のプロファイルに保存されます。

## 保存先・更新時の注意

- `MOVIE_DATA`: CLIP の録画と完了情報。
- `TAPE_DATA`: TAPE 録音データ。
- `state/webview2`: 実行時に作成・使用する専用アプリのプロファイル。実行中に削除しないでください。

専用の WebView2 アプリでは、同じ展開フォルダーを再使用すると設定を引き継ぎ、新しい展開先では別の `state/webview2` プロファイルを使用します。Edge による代替起動では通常の Edge プロファイルを使用するため、同じローカルアドレスの設定・権限は別の展開フォルダー間でも共有される場合があります。更新や移動の前に正常終了し、必要なデータをバックアップしてください。

## リリースパッケージ内容

公開パッケージには、アプリ本体、実行時に必要な入力ファイル、WebView2 SDK ファイル、TAPE ヘルパー、ライセンス・通知、空のデータ保存フォルダーが含まれます。

```text
μSX_REMO-CON/
  μSX_REMO-CON.exe
  index.html
  Movie.js
  NativeMonitor.js
  NativePlayback.js
  MovieWorker.cs
  NativeMonitor.cs
  Start-RemoConDisplay.cmd
  Start-RemoConDisplay.ps1
  Stop-RemoConDisplay.cmd
  Stop-RemoConDisplay.ps1
  Microsoft.Web.WebView2.Core.dll
  Microsoft.Web.WebView2.WinForms.dll
  WebView2Loader.dll
  tape_cmd/
  notices/
  MOVIE_DATA/
  TAPE_DATA/
  README.md
  README_ja.md
  LICENSE
  THIRD_PARTY_NOTICES.md
  release-manifest.json
```

パッケージ構成を維持してください。上記の二つの C# ファイルはホストが起動時にコンパイルする実行時入力であり、開発用ファイルの置き忘れではありません。

## 困ったとき

- **起動しない:** ZIP 全体の展開、書き込み権限、WebView2 Evergreen Runtime を確認します。
- **アドレス使用中:** 別の REMO-CON を正常終了します。同じフォルダーの代替ホストを完全停止する場合は Stop CMD を使います。動作中の所有記録を手動削除しないでください。
- **古い代替ホストが再利用できない:** いったん Stop CMD で終了してから Start CMD を実行します。
- **映像・音声がない:** DEVICE の許可と三つの選択、配線、対応解像度を確認します。
- **KeyScan / テキスト入力が動作しない:** KeyScan PORT、接続状態、他アプリによるポート使用を確認します。
- **ESERAMair 転送に失敗する:** ESERAMair のネットワークと、PC から `eseram.local:8080` に到達できることを確認します。
- **TAPE が動作しない:** X-Converter / AtomU の接続、必要な AtomU ファームウェア、AtomU PORT、ドライバー、他アプリによるポート使用を確認します。

## ライセンス

KickState 作成部分の利用条件は [LICENSE](LICENSE)、同梱する第三者コンポーネントは [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) を参照してください。
