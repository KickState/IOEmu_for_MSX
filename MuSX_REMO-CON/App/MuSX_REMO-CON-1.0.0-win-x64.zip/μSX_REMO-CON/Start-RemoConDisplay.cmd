@echo off
setlocal
rem Open the supported Microsoft Edge fallback and the owned loopback display.
rem A failed hidden launch presents a plain-language error dialog instead.
rem Optional PowerShell parameters (for example, -Port 8781) are forwarded.
start "" /b powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Start-RemoConDisplay.ps1" -OpenBrowser -ShowLaunchError %*
endlocal
exit /b
