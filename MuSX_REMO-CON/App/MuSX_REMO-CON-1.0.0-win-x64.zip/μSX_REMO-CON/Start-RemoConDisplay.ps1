[CmdletBinding()]
param(
    [ValidateRange(1024, 65535)]
    [int]$Port = 8780,
    [switch]$OpenBrowser,
    [switch]$ShowLaunchError
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# The loopback HTTP origin supports browser camera permissions. Capture and
# rendering are managed by the application without an external capture service.
$root = Split-Path -Parent $PSCommandPath
$indexPath = Join-Path $root 'index.html'
$stateDirectory = Join-Path $root 'state'
$hostStatePath = Join-Path $stateDirectory 'display-host.json'
$hostToken = [guid]::NewGuid().ToString('N')
$hostRoot = [IO.Path]::GetFullPath($root).TrimEnd('\').ToUpperInvariant()
$hostProcessStarted = [Diagnostics.Process]::GetCurrentProcess().StartTime.ToUniversalTime().Ticks.ToString()
$hostMode = if ($OpenBrowser) { 'edge' } else { 'dedicated' }
$startupGate = $null
$startupGateHeld = $false
$keyScanPort = $null
$keyScanPortName = $null
$tapeHelperPath = Join-Path $root 'tape_cmd\playback.exe'
$tapeCaptureHelperPath = Join-Path $root 'tape_cmd\capture.exe'
$tapeStateDirectory = Join-Path $stateDirectory 'tape-playback'
$tapeCaptureStateDirectory = Join-Path $stateDirectory 'tape-capture'
$tapeDataDirectory = Join-Path $root 'TAPE_DATA'
$movieWorker = $null
$liveMonitor = $null
$tapePlayback = $null
$tapeCapture = $null
if (-not (Test-Path -LiteralPath $indexPath -PathType Leaf)) {
    throw "Display page is missing: $indexPath"
}

function Get-MicrosoftEdgeCandidates {
    # Read only the registered executable and the standard stable-channel paths.
    foreach ($hive in @([Microsoft.Win32.RegistryHive]::CurrentUser, [Microsoft.Win32.RegistryHive]::LocalMachine)) {
        foreach ($view in @([Microsoft.Win32.RegistryView]::Registry64, [Microsoft.Win32.RegistryView]::Registry32)) {
            $base = $null; $key = $null
            try {
                $base = [Microsoft.Win32.RegistryKey]::OpenBaseKey($hive, $view)
                $key = $base.OpenSubKey('SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe')
                if ($key) { $value = $key.GetValue(''); if ($value -is [string]) { $value } }
            } catch { } finally { if ($key) { $key.Dispose() }; if ($base) { $base.Dispose() } }
        }
    }
    foreach ($folder in @([Environment]::GetFolderPath('LocalApplicationData'), [Environment]::GetFolderPath('ProgramFilesX86'), [Environment]::GetFolderPath('ProgramFiles'))) {
        if ($folder) { Join-Path $folder 'Microsoft\Edge\Application\msedge.exe' }
    }
}

function Resolve-MicrosoftEdge {
    foreach ($candidate in @(Get-MicrosoftEdgeCandidates)) {
        try {
            $path = [Environment]::ExpandEnvironmentVariables(([string]$candidate).Trim().Trim('"'))
            if ([IO.Path]::IsPathRooted($path) -and [IO.Path]::GetFileName($path) -ieq 'msedge.exe' -and
                (Test-Path -LiteralPath $path -PathType Leaf)) { return [IO.Path]::GetFullPath($path) }
        } catch { }
    }
    throw 'Microsoft Edge was not found. Install Microsoft Edge or use the dedicated REMO-CON application. No default browser was opened.'
}

function Start-MicrosoftEdge([string]$Executable, [string]$Url) {
    $info = [Diagnostics.ProcessStartInfo]::new()
    $info.FileName = $Executable
    $info.Arguments = '--new-window ' + (ConvertTo-ProcessArgument $Url)
    $info.UseShellExecute = $false
    $process = [Diagnostics.Process]::Start($info)
    if (-not $process) { throw 'Microsoft Edge could not be launched.' }
    # Edge can delegate to its existing browser process; never own or stop it.
    $process.Dispose()
}

function Show-LaunchFailure([string]$Message) {
    if ($ShowLaunchError) {
        try {
            Add-Type -AssemblyName PresentationFramework
            [void][System.Windows.MessageBox]::Show($Message, 'MuSX REMO-CON', 'OK', 'Error')
        } catch { }
    }
}

function Write-HostState {
    [IO.Directory]::CreateDirectory($stateDirectory) | Out-Null
    $record = [ordered]@{
        v = 1
        pid = $PID
        port = $Port
        token = $hostToken
        startedAt = [datetime]::UtcNow.ToString('o')
        root = $hostRoot
        processStarted = $hostProcessStarted
        mode = $hostMode
    } | ConvertTo-Json -Compress
    $temporary = "$hostStatePath.$PID.tmp"
    try {
        [IO.File]::WriteAllText($temporary, $record, [Text.UTF8Encoding]::new($false))
        Move-Item -LiteralPath $temporary -Destination $hostStatePath -Force
    } finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue }
    }
}

function Remove-HostState {
    try {
        $current = Get-Content -LiteralPath $hostStatePath -Raw -Encoding utf8 | ConvertFrom-Json -ErrorAction Stop
        if ([string]$current.token -eq $hostToken) {
            Remove-Item -LiteralPath $hostStatePath -Force -ErrorAction SilentlyContinue
        }
    } catch {}
}

function Get-HostProof([string]$Token, [string]$Nonce, [string]$Root, [int]$HostId, [int]$HostPort, [string]$Started, [string]$Mode) {
    $hmac = [Security.Cryptography.HMACSHA256]::new([Text.Encoding]::UTF8.GetBytes($Token))
    try {
        $message = "remocon-health-v1`n$Nonce`n$Root`n$HostId`n$HostPort`n$Started`n$Mode"
        return [BitConverter]::ToString($hmac.ComputeHash([Text.Encoding]::UTF8.GetBytes($message))).Replace('-', '').ToLowerInvariant()
    } finally { $hmac.Dispose() }
}

function Release-StartupGate {
    if ($script:startupGateHeld) { $script:startupGate.ReleaseMutex(); $script:startupGateHeld = $false }
    if ($script:startupGate) { $script:startupGate.Dispose(); $script:startupGate = $null }
}

function Enter-StartupGate {
    $hash = [Security.Cryptography.SHA256]::Create()
    try { $name = [BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($hostRoot))).Replace('-', '') }
    finally { $hash.Dispose() }
    $script:startupGate = [Threading.Mutex]::new($false, ('Local\RemoconFallback_' + $name))
    try { $script:startupGateHeld = $script:startupGate.WaitOne(15000) }
    catch [Threading.AbandonedMutexException] { $script:startupGateHeld = $true }
    if (-not $script:startupGateHeld) { throw 'Another REMO-CON start is still in progress. Wait and retry.' }
}

function Read-FallbackOwnership {
    if (-not (Test-Path -LiteralPath $hostStatePath)) { return $null }
    $raw = [IO.File]::ReadAllText($hostStatePath)
    $record = $raw | ConvertFrom-Json -ErrorAction Stop
    if ($record.v -ne 1 -or [int]$record.pid -le 0 -or [int]$record.port -ne $Port -or
        [string]$record.token -cnotmatch '^[a-f0-9]{32}$') { throw 'The project host record is invalid or belongs to another port.' }
    # Older records may be retired only when their process is gone and binding
    # succeeds. A live legacy record without a health proof is never reused.
    if ($record.PSObject.Properties['root'] -and [string]$record.root -cne $hostRoot) { throw 'The host record belongs to another application folder.' }
    $process = $null
    try { $process = [Diagnostics.Process]::GetProcessById([int]$record.pid) }
    catch [ArgumentException] { return @{ Raw = $raw; Reuse = $false } }
    try {
        if (-not $record.PSObject.Properties['root'] -or -not $record.PSObject.Properties['processStarted'] -or
            -not $record.PSObject.Properties['mode'] -or [string]$record.mode -cne 'edge' -or
            $process.ProcessName -ine 'powershell' -or
            $process.StartTime.ToUniversalTime().Ticks.ToString() -cne [string]$record.processStarted) {
            throw 'The recorded process is not a verified Edge fallback host. Close its application normally or use Stop-RemoConDisplay.cmd.'
        }
        $nonce = [guid]::NewGuid().ToString('N')
        # Do not send the stored token to a listener whose ownership is unproven.
        $request = [Net.HttpWebRequest]::Create("http://127.0.0.1:$Port/__remocon/health/$nonce")
        $request.Proxy = $null; $request.AllowAutoRedirect = $false; $request.Timeout = 3000; $request.ReadWriteTimeout = 3000
        $response = $request.GetResponse()
        try {
            if ([int]$response.StatusCode -ne 200 -or $response.ContentLength -lt 0 -or $response.ContentLength -gt 1024) { throw 'Unexpected host health response.' }
            $reader = [IO.StreamReader]::new($response.GetResponseStream())
            try { $reply = $reader.ReadToEnd() | ConvertFrom-Json -ErrorAction Stop } finally { $reader.Dispose() }
        } finally { $response.Dispose() }
        $expected = Get-HostProof ([string]$record.token) $nonce $hostRoot ([int]$record.pid) $Port ([string]$record.processStarted) 'edge'
        if ($reply.service -cne 'remocon-health-v1' -or $reply.proof -cne $expected -or $process.HasExited -or
            [IO.File]::ReadAllText($hostStatePath) -cne $raw) { throw 'Host ownership/health proof did not match.' }
        return @{ Raw = $raw; Reuse = $true }
    } finally { if ($process) { $process.Dispose() } }
}

function Close-KeyScanPort {
    if ($null -eq $keyScanPort) { return }
    try { if ($keyScanPort.IsOpen) { $keyScanPort.Close() } } catch {}
    try { $keyScanPort.Dispose() } catch {}
    $script:keyScanPort = $null
    $script:keyScanPortName = $null
}

function ConvertTo-ProcessArgument([string]$Value) {
    # ProcessStartInfo.Arguments is a single Windows command line on the normal
    # Windows PowerShell/.NET Framework host. Quote according to CommandLineToArgvW.
    if ($null -eq $Value -or $Value.Length -eq 0) { return '""' }
    if ($Value -notmatch '[\s"]') { return $Value }
    $builder = [Text.StringBuilder]::new()
    [void]$builder.Append([char]'"')
    $slashes = 0
    for ($index = 0; $index -lt $Value.Length; $index++) {
        $character = $Value[$index]
        if ($character -eq '\') { $slashes++; continue }
        if ($character -eq '"') {
            if ($slashes -gt 0) { [void]$builder.Append([char]'\', ($slashes * 2)) }
            [void]$builder.Append([char]'\')
            [void]$builder.Append([char]'"')
            $slashes = 0
            continue
        }
        if ($slashes -gt 0) { [void]$builder.Append([char]'\', $slashes); $slashes = 0 }
        [void]$builder.Append($character)
    }
    if ($slashes -gt 0) { [void]$builder.Append([char]'\', ($slashes * 2)) }
    [void]$builder.Append([char]'"')
    return $builder.ToString()
}

function Remove-TapePlaybackFiles([object]$Operation) {
    if ($null -eq $Operation) { return }
    try {
        if (Test-Path -LiteralPath $Operation.Directory) {
            Remove-Item -LiteralPath $Operation.Directory -Recurse -Force -ErrorAction SilentlyContinue
        }
    } catch {}
}

function Read-TapePlaybackReport([string]$ReportPath) {
    $json = Get-Content -LiteralPath $ReportPath -Raw -Encoding utf8 -ErrorAction Stop
    if ([string]::IsNullOrWhiteSpace($json)) { throw 'The completion report is empty.' }
    $report = $json | ConvertFrom-Json -ErrorAction Stop
    foreach ($name in @('play_complete_received','buffer_underrun_count','input_buffer_overflow','atomu_rx_crc_errors','atomu_rx_sequence_errors','pc_rx_crc_errors','pc_rx_sequence_errors')) {
        if ($null -eq $report.PSObject.Properties[$name]) { throw "The completion report is missing '$name'." }
    }
    $hasWarning = -not [bool]$report.play_complete_received
    foreach ($name in @('buffer_underrun_count','input_buffer_overflow','atomu_rx_crc_errors','atomu_rx_sequence_errors','pc_rx_crc_errors','pc_rx_sequence_errors')) {
        if ([int64]$report.$name -ne 0) { $hasWarning = $true }
    }
    return @{ HasWarning = $hasWarning }
}

function Get-TapePlaybackStatus {
    if ($null -eq $tapePlayback) { return @{ state = 'Idle'; fileName = '' } }
    $operation = $tapePlayback
    if (-not $operation.Process.HasExited) {
        if ($operation.StopRequested) { $operation.State = 'Stopping' }
        elseif (Test-Path -LiteralPath $operation.BeginPath) { $operation.State = 'Playing' }
        elseif (Test-Path -LiteralPath $operation.ReadyPath) { $operation.State = 'Ready' }
        return @{ state = $operation.State; fileName = $operation.FileName; error = $operation.Error }
    }
    try { $operation.OutputTask.Wait(1000) | Out-Null } catch {}
    try { $operation.ErrorTask.Wait(1000) | Out-Null } catch {}
    try { $operation.OutputFile.Dispose() } catch {}
    try { $operation.ErrorFile.Dispose() } catch {}
    $output = ''
    try {
        if (Test-Path -LiteralPath $operation.OutputPath) { $output = Get-Content -LiteralPath $operation.OutputPath -Raw -Encoding utf8 }
        if (Test-Path -LiteralPath $operation.ErrorPath) { $output += "`n" + (Get-Content -LiteralPath $operation.ErrorPath -Raw -Encoding utf8) }
    } catch {}
    if ($operation.StopRequested) {
        # Keep acknowledgement detail and the existing selection policy in
        # the internal state. Only a zero exit is eligible for normal stopped
        # presentation; a nonzero exit must still be reported as a failure.
        if ($operation.Process.ExitCode -eq 0) {
            $operation.State = if ($output -match 'Playback aborted locally, but AtomU did not acknowledge') { 'Stop uncertain' } elseif ($output -match 'Playback aborted\.') { 'Stopped' } else { 'Stop uncertain' }
            $operation.Error = ''
        } else {
            $operation.State = 'Error'
            $operation.Error = 'Direct Playback did not stop cleanly. Try playback again.'
        }
    } elseif ($operation.Process.ExitCode -ne 0) {
        $operation.State = 'Error'
        $operation.Error = if ($output) { 'Direct Playback failed. ' + (($output -split "`r?`n" | Where-Object { $_ })[-1]) } else { "Direct Playback helper exited with code $($operation.Process.ExitCode)." }
    } elseif (-not (Test-Path -LiteralPath $operation.ReportPath)) {
        $operation.State = 'Error'
        $operation.Error = 'Direct Playback finished without its completion report.'
    } else {
        try {
            $reportResult = Read-TapePlaybackReport $operation.ReportPath
            $operation.State = if ($reportResult.HasWarning) { 'Complete with warnings' } else { 'Complete' }
        } catch {
            $operation.State = 'Error'
            $operation.Error = 'Direct Playback completed, but its completion report is invalid. ' + $_.Exception.Message
        }
    }
    return @{ state = $operation.State; fileName = $operation.FileName; error = $operation.Error }
}

function Start-TapePlayback([string]$RequestBody) {
    if (-not (Test-Path -LiteralPath $tapeHelperPath -PathType Leaf)) { throw "Direct Playback helper is missing: $tapeHelperPath" }
    $captureStatus = Get-TapeCaptureStatus
    if ($captureStatus.state -in @('Starting','Recording','Stopping')) { throw 'Direct REC is already using the AtomU port.' }
    if ($tapeCapture) { Remove-TapePlaybackFiles $tapeCapture; $script:tapeCapture = $null }
    $current = Get-TapePlaybackStatus
    if ($current.state -in @('Preparing','Ready','Playing','Stopping')) { throw 'Direct Playback is already active.' }
    if ($tapePlayback) { Remove-TapePlaybackFiles $tapePlayback; $script:tapePlayback = $null }
    $payload = $RequestBody | ConvertFrom-Json -ErrorAction Stop
    $requestedPort = [string]$payload.port
    $fileName = [string]$payload.fileName
    $sourceProperty = $payload.PSObject.Properties['source']
    if ($null -eq $sourceProperty) { throw 'The selected tape file source is missing.' }
    $source = [string]$sourceProperty.Value
    if ([string]::IsNullOrWhiteSpace($requestedPort)) { throw 'Choose an AtomU COM port first.' }
    if (@([IO.Ports.SerialPort]::GetPortNames()) -notcontains $requestedPort) { throw 'The selected AtomU COM port is no longer available. Refresh the list and choose it again.' }
    if ($keyScanPortName -and $requestedPort -eq $keyScanPortName) { throw "AtomU port $requestedPort is currently open for KeyScan-Emu. Disconnect KeyScan manually before choosing that same port." }
    if ($fileName -notmatch '(?i)\.casraw(?:\.zip)?$') { throw 'Choose one .casraw or .casraw.zip file.' }
    if ($source -eq 'tape-data') {
        if ([IO.Path]::GetFileName($fileName) -ne $fileName -or $fileName -notmatch '(?i)\.casraw(?:\.zip)?$') { throw 'The selected TAPE_DATA filename is invalid.' }
        $tapeDataPath = Join-Path $tapeDataDirectory $fileName
        if (-not (Test-Path -LiteralPath $tapeDataPath -PathType Leaf)) { throw 'The selected TAPE_DATA file is no longer available.' }
        $fileBytes = [IO.File]::ReadAllBytes($tapeDataPath)
    } elseif ($source -eq 'browser') {
        $encodedProperty = $payload.PSObject.Properties['fileBase64']
        if ($null -eq $encodedProperty) { throw 'The selected browser tape file could not be read.' }
        $encoded = [string]$encodedProperty.Value
        if ([string]::IsNullOrWhiteSpace($encoded)) { throw 'Choose a tape file first.' }
        try { $fileBytes = [Convert]::FromBase64String($encoded) } catch { throw 'The selected tape file could not be read.' }
    } else {
        throw 'The selected tape file source is invalid.'
    }
    if ($fileBytes.Length -lt 1) { throw 'The selected tape file is empty.' }
    $operationDirectory = Join-Path $tapeStateDirectory ([guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($operationDirectory) | Out-Null
    $extension = if ($fileName.EndsWith('.casraw.zip', [StringComparison]::OrdinalIgnoreCase)) { '.casraw.zip' } else { '.casraw' }
    $sourcePath = Join-Path $operationDirectory "source$extension"
    $readyPath = Join-Path $operationDirectory 'ready.marker'
    $beginPath = Join-Path $operationDirectory 'begin.marker'
    $stopPath = Join-Path $operationDirectory 'stop.marker'
    $reportPath = Join-Path $operationDirectory 'report.json'
    $outputPath = Join-Path $operationDirectory 'helper-output.txt'
    $errorPath = Join-Path $operationDirectory 'helper-error.txt'
    try {
        [IO.File]::WriteAllBytes($sourcePath, $fileBytes)
        $startInfo = [Diagnostics.ProcessStartInfo]::new()
        $startInfo.FileName = $tapeHelperPath
        $startInfo.UseShellExecute = $false
        $startInfo.CreateNoWindow = $true
        $startInfo.RedirectStandardOutput = $true
        $startInfo.RedirectStandardError = $true
        $startInfo.Arguments = (@($sourcePath, '--port', $requestedPort, '--report', $reportPath, '--gui-ready-file', $readyPath, '--gui-begin-file', $beginPath, '--gui-stop-file', $stopPath) | ForEach-Object { ConvertTo-ProcessArgument ([string]$_) }) -join ' '
        $process = [Diagnostics.Process]::new()
        $process.StartInfo = $startInfo
        if (-not $process.Start()) { throw 'Unable to start Direct Playback helper.' }
        $outputFile = [IO.File]::Open($outputPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::Read)
        $errorFile = [IO.File]::Open($errorPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::Read)
        $outputTask = $process.StandardOutput.BaseStream.CopyToAsync($outputFile)
        $errorTask = $process.StandardError.BaseStream.CopyToAsync($errorFile)
        $script:tapePlayback = [pscustomobject]@{ Process = $process; OutputTask = $outputTask; ErrorTask = $errorTask; OutputFile = $outputFile; ErrorFile = $errorFile; Directory = $operationDirectory; ReadyPath = $readyPath; BeginPath = $beginPath; StopPath = $stopPath; ReportPath = $reportPath; OutputPath = $outputPath; ErrorPath = $errorPath; FileName = $fileName; State = 'Preparing'; StopRequested = $false; Error = '' }
    } catch {
        Remove-Item -LiteralPath $operationDirectory -Recurse -Force -ErrorAction SilentlyContinue
        throw
    }
    return Get-TapePlaybackStatus
}

function Begin-TapePlayback {
    $current = Get-TapePlaybackStatus
    if ($current.state -ne 'Ready' -or $null -eq $tapePlayback) { throw 'Direct Playback is not ready to begin.' }
    [IO.File]::WriteAllBytes($tapePlayback.BeginPath, [byte[]]::new(0))
    $tapePlayback.State = 'Playing'
    return Get-TapePlaybackStatus
}

function Request-TapePlaybackStop {
    $current = Get-TapePlaybackStatus
    if ($current.state -notin @('Preparing','Ready','Playing') -or $null -eq $tapePlayback) { throw 'No Direct Playback operation can be stopped.' }
    [IO.File]::WriteAllBytes($tapePlayback.StopPath, [byte[]]::new(0))
    $tapePlayback.StopRequested = $true
    $tapePlayback.State = 'Stopping'
    return Get-TapePlaybackStatus
}

function Get-TapeCaptureStatus {
    if ($null -eq $tapeCapture) { return @{ state = 'Idle'; fileName = ''; operation = 'record' } }
    $operation = $tapeCapture
    if (-not $operation.Process.HasExited) {
        if ($operation.StopRequested) { $operation.State = 'Stopping' }
        elseif ($operation.State -eq 'Starting') { $operation.State = 'Recording' }
        return @{ state = $operation.State; fileName = $operation.FileName; operation = 'record'; error = $operation.Error }
    }
    try { $operation.OutputTask.Wait(1000) | Out-Null } catch {}
    try { $operation.ErrorTask.Wait(1000) | Out-Null } catch {}
    try { $operation.OutputFile.Dispose() } catch {}
    try { $operation.ErrorFile.Dispose() } catch {}
    $output = ''
    try {
        if (Test-Path -LiteralPath $operation.HelperOutputPath) { $output = Get-Content -LiteralPath $operation.HelperOutputPath -Raw -Encoding utf8 }
        if (Test-Path -LiteralPath $operation.ErrorPath) { $output += "`n" + (Get-Content -LiteralPath $operation.ErrorPath -Raw -Encoding utf8) }
    } catch {}
    if ($operation.Process.ExitCode -ne 0) {
        $operation.State = 'Error'
        $operation.Error = if ($output) { 'Direct REC failed. ' + (($output -split "`r?`n" | Where-Object { $_ })[-1]) } else { "Direct REC helper exited with code $($operation.Process.ExitCode)." }
    } elseif (-not (Test-Path -LiteralPath $operation.OutputPath -PathType Leaf) -or (Get-Item -LiteralPath $operation.OutputPath).Length -lt 1) {
        $operation.State = 'Error'
        $operation.Error = 'Direct REC completed without a saved .casraw.zip file.'
    } elseif (-not (Test-Path -LiteralPath $operation.ReportPath -PathType Leaf)) {
        $operation.State = 'Error'
        $operation.Error = 'Direct REC completed without its completion report.'
    } else {
        try {
            $report = Get-Content -LiteralPath $operation.ReportPath -Raw -Encoding utf8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            foreach ($name in @('sample_rate','valid_samples','sample_loss','buffer_overflow','frame_crc_errors','sequence_errors')) {
                if ($null -eq $report.PSObject.Properties[$name]) { throw "The completion report is missing '$name'." }
            }
            if ([int]$report.sample_rate -ne 38400) { throw 'The completion report has an unexpected sample rate.' }
            $hasWarning = $false
            foreach ($name in @('sample_loss','buffer_overflow','frame_crc_errors','sequence_errors')) {
                if ([int64]$report.$name -ne 0) { $hasWarning = $true }
            }
            $operation.State = if ($hasWarning) { 'Recorded with warnings' } else { 'Recorded' }
        } catch {
            $operation.State = 'Error'
            $operation.Error = 'Direct REC completed, but its completion report is invalid. ' + $_.Exception.Message
        }
    }
    return @{ state = $operation.State; fileName = $operation.FileName; operation = 'record'; recordedFileName = if ($operation.State -in @('Recorded','Recorded with warnings')) { $operation.FileName } else { '' }; error = $operation.Error }
}

function New-TapeCaptureFileName([string]$RecName) {
    # A label only: strip Windows-invalid characters, including separators,
    # and bound its size so the fixed project path remains practical.
    $safeName = ($RecName -replace '[<>:"/\\|?*\x00-\x1F]', '').Trim().Trim('.')
    if ($safeName.Length -gt 64) { $safeName = $safeName.Substring(0, 64).TrimEnd(' ', '.') }
    if ([string]::IsNullOrWhiteSpace($safeName)) { $safeName = 'REC' }
    if ($safeName -match '^(?i:CON|PRN|AUX|NUL|COM[1-9¹²³]|LPT[1-9¹²³])(?:\.|$)') { $safeName = '_' + $safeName }
    return $safeName + '_' + [datetime]::Now.ToString('yyyyMMdd_HHmmss_fff') + '.casraw.zip'
}

function Start-TapeCapture([string]$RequestBody) {
    if (-not (Test-Path -LiteralPath $tapeCaptureHelperPath -PathType Leaf)) { throw "Direct REC helper is missing: $tapeCaptureHelperPath" }
    $playbackStatus = Get-TapePlaybackStatus
    if ($playbackStatus.state -in @('Preparing','Ready','Playing','Stopping')) { throw 'Direct Playback is already using the AtomU port.' }
    $current = Get-TapeCaptureStatus
    if ($current.state -in @('Starting','Recording','Stopping')) { throw 'Direct REC is already active.' }
    if ($tapeCapture) { Remove-TapePlaybackFiles $tapeCapture; $script:tapeCapture = $null }
    $payload = $RequestBody | ConvertFrom-Json -ErrorAction Stop
    $requestedPort = [string]$payload.port
    if ([string]::IsNullOrWhiteSpace($requestedPort)) { throw 'Choose an AtomU COM port first.' }
    if (@([IO.Ports.SerialPort]::GetPortNames()) -notcontains $requestedPort) { throw 'The selected AtomU COM port is no longer available. Refresh the list and choose it again.' }
    if ($keyScanPortName -and $requestedPort -eq $keyScanPortName) { throw "AtomU port $requestedPort is currently open for KeyScan-Emu. Disconnect KeyScan manually before choosing that same port." }
    [IO.Directory]::CreateDirectory($tapeDataDirectory) | Out-Null
    $nameProperty = $payload.PSObject.Properties['recName']
    $recName = if ($null -ne $nameProperty) { [string]$nameProperty.Value } else { '' }
    $fileName = New-TapeCaptureFileName $recName
    $outputPath = Join-Path $tapeDataDirectory $fileName
    if (Test-Path -LiteralPath $outputPath) { throw 'A recording with this name already exists. Press REC again to use a new timestamp.' }
    $operationDirectory = Join-Path $tapeCaptureStateDirectory ([guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($operationDirectory) | Out-Null
    $stopPath = Join-Path $operationDirectory 'stop.marker'
    $reportPath = Join-Path $operationDirectory 'report.json'
    $helperOutputPath = Join-Path $operationDirectory 'helper-output.txt'
    $errorPath = Join-Path $operationDirectory 'helper-error.txt'
    try {
        $startInfo = [Diagnostics.ProcessStartInfo]::new()
        $startInfo.FileName = $tapeCaptureHelperPath
        $startInfo.UseShellExecute = $false
        $startInfo.CreateNoWindow = $true
        $startInfo.RedirectStandardOutput = $true
        $startInfo.RedirectStandardError = $true
        $startInfo.Arguments = (@($outputPath, '--port', $requestedPort, '--sample-rate', '38400', '--report', $reportPath, '--stop-file', $stopPath) | ForEach-Object { ConvertTo-ProcessArgument ([string]$_) }) -join ' '
        $process = [Diagnostics.Process]::new()
        $process.StartInfo = $startInfo
        if (-not $process.Start()) { throw 'Unable to start Direct REC helper.' }
        $outputFile = [IO.File]::Open($helperOutputPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::Read)
        $errorFile = [IO.File]::Open($errorPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::Read)
        $outputTask = $process.StandardOutput.BaseStream.CopyToAsync($outputFile)
        $errorTask = $process.StandardError.BaseStream.CopyToAsync($errorFile)
        $script:tapeCapture = [pscustomobject]@{ Process = $process; OutputTask = $outputTask; ErrorTask = $errorTask; OutputFile = $outputFile; ErrorFile = $errorFile; Directory = $operationDirectory; StopPath = $stopPath; ReportPath = $reportPath; OutputPath = $outputPath; HelperOutputPath = $helperOutputPath; ErrorPath = $errorPath; FileName = $fileName; State = 'Starting'; StopRequested = $false; Error = '' }
    } catch {
        Remove-Item -LiteralPath $operationDirectory -Recurse -Force -ErrorAction SilentlyContinue
        throw
    }
    return @{ state = 'Starting'; fileName = $fileName; operation = 'record' }
}

function Request-TapeCaptureStop {
    $current = Get-TapeCaptureStatus
    if ($current.state -notin @('Starting','Recording') -or $null -eq $tapeCapture) { throw 'No Direct REC operation can be stopped.' }
    [IO.File]::WriteAllBytes($tapeCapture.StopPath, [byte[]]::new(0))
    $tapeCapture.StopRequested = $true
    $tapeCapture.State = 'Stopping'
    return Get-TapeCaptureStatus
}

function Request-TapeOperationStop {
    $playbackStatus = Get-TapePlaybackStatus
    if ($playbackStatus.state -in @('Preparing','Ready','Playing')) { return Request-TapePlaybackStop }
    return Request-TapeCaptureStop
}

function Get-TapeOperationStatus {
    $captureStatus = Get-TapeCaptureStatus
    if ($captureStatus.state -ne 'Idle') { return $captureStatus }
    return Get-TapePlaybackStatus
}

function Send-JsonResponse([System.IO.Stream]$Stream, [int]$StatusCode, [object]$Body) {
    $json = $Body | ConvertTo-Json -Compress -Depth 10
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $statusText = switch ($StatusCode) { 200 { 'OK' } 204 { 'No Content' } 400 { 'Bad Request' } 403 { 'Forbidden' } 404 { 'Not Found' } 409 { 'Conflict' } 413 { 'Payload Too Large' } 500 { 'Internal Server Error' } default { 'Error' } }
    $header = "HTTP/1.1 $StatusCode $statusText`r`nContent-Type: application/json; charset=utf-8`r`nCache-Control: no-store`r`nContent-Length: $($bytes.Length)`r`nConnection: close`r`n`r`n"
    $headBytes = [Text.Encoding]::ASCII.GetBytes($header)
    $Stream.Write($headBytes, 0, $headBytes.Length)
    if ($bytes.Length) { $Stream.Write($bytes, 0, $bytes.Length) }
}

function Read-RequestHeaders([System.IO.Stream]$Stream) {
    $buffer = [IO.MemoryStream]::new()
    $last = [byte[]](0,0,0,0)
    while ($buffer.Length -lt 16384) {
        $value = $Stream.ReadByte()
        if ($value -lt 0) { throw 'Request headers ended unexpectedly.' }
        $buffer.WriteByte([byte]$value)
        $last[0] = $last[1]; $last[1] = $last[2]; $last[2] = $last[3]; $last[3] = [byte]$value
        if ($last[0] -eq 13 -and $last[1] -eq 10 -and $last[2] -eq 13 -and $last[3] -eq 10) { break }
    }
    if ($buffer.Length -ge 16384) { throw 'Request headers are too large.' }
    $lines = ([Text.Encoding]::ASCII.GetString($buffer.ToArray()) -split "`r`n")
    if ([string]::IsNullOrWhiteSpace($lines[0])) { throw 'Request line is missing.' }
    $headers = @{}
    foreach ($line in $lines[1..($lines.Length - 1)]) {
        if ($line -match '^([^:]+):\s*(.*)$') {
            $key = $Matches[1].ToLowerInvariant()
            if ($headers.ContainsKey($key)) { throw 'Duplicate request header.' }
            $headers[$key] = $Matches[2]
        }
    }
    if ($headers.ContainsKey('transfer-encoding') -or $headers.ContainsKey('expect')) { throw 'Unsupported request framing.' }
    return @{ RequestLine = $lines[0]; ContentLength = if ($headers.ContainsKey('content-length')) { [int]$headers['content-length'] } else { 0 } }
}

function Read-RequestBody([System.IO.Stream]$Stream, [int]$Length) {
    if ($Length -le 0) { return '' }
    $buffer = [byte[]]::new($Length)
    $read = 0
    while ($read -lt $Length) {
        $count = $Stream.Read($buffer, $read, $Length - $read)
        if ($count -le 0) { throw 'Request body ended unexpectedly.' }
        $read += $count
    }
    return [Text.Encoding]::UTF8.GetString($buffer)
}

try {
$listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, $Port)
$url = "http://127.0.0.1:$Port/"
$edgeExecutable = $null
if ($OpenBrowser) {
    try {
        $edgeExecutable = Resolve-MicrosoftEdge
        Enter-StartupGate
        $ownership = Read-FallbackOwnership
        if ($ownership -and $ownership.Reuse) {
            Start-MicrosoftEdge $edgeExecutable $url
            Write-Host "MuSX REMO-CON display reopened: $url"
            return
        }
    } catch {
        Show-LaunchFailure ('REMO-CON cannot safely start or reuse this address. Another instance may be active. ' + $_.Exception.Message)
        throw
    }
}
try {
    $listener.Start()
} catch {
    $message = "MuSX REMO-CON could not start because its local display address ($url) is already in use. Close the other display instance and double-click Start-RemoConDisplay.cmd again."
    if ($ShowLaunchError) {
        try {
            Add-Type -AssemblyName PresentationFramework
            [void][System.Windows.MessageBox]::Show($message, 'MuSX REMO-CON', 'OK', 'Error')
        } catch {
            # The caller still receives the explanatory terminating error.
        }
    }
    throw $message
}
try {
    if ($OpenBrowser -and $ownership) {
        # Binding succeeded while the project startup gate is held; no listener
        # exists at this port. Retire only the unchanged record of a gone PID.
        if ([IO.File]::ReadAllText($hostStatePath) -cne $ownership.Raw) { throw 'Host record changed during startup; retry after checking the existing instance.' }
        Remove-Item -LiteralPath $hostStatePath -ErrorAction Stop
    }
    Add-Type -Path (Join-Path $root 'MovieWorker.cs') -ReferencedAssemblies 'System.Web.Extensions','System.Core'
    $movieWorker = [Remocon.MovieWorker]::new($root, $url.TrimEnd('/'), $hostToken)
    Add-Type -Path (Join-Path $root 'NativeMonitor.cs') -ReferencedAssemblies 'System.Core'
    $liveMonitor = [RemoLive.Controller]::new()
    $movieWorker.AudioRequest = $liveMonitor.PlaybackHandler
    Write-HostState
} catch {
    if ($movieWorker) { $movieWorker.Dispose() }
    $listener.Stop()
    throw
}
try {
    if ($OpenBrowser) {
        try { Start-MicrosoftEdge $edgeExecutable $url }
        catch { Show-LaunchFailure ('Microsoft Edge could not open REMO-CON. '+$_.Exception.Message); throw }
    }
    Release-StartupGate
    Write-Host "MuSX REMO-CON display: $url (Ctrl+C to stop)"
    $running = $true
    while ($running) {
        $client = $listener.AcceptTcpClient()
        $readDeadline = [Remocon.MovieWorker]::BoundControlRead($client)
        try {
            $stream = $client.GetStream()
            $stream.ReadTimeout = 2000
            $stream.WriteTimeout = 2000
            $request = Read-RequestHeaders $stream
            $requestLine = $request.RequestLine
            $contentLength = $request.ContentLength
            if ($contentLength -lt 0) { throw 'Request body length is invalid.' }
            $isRootGet = $requestLine -match '^GET /(?: HTTP/|\?[^ ]* HTTP/)'
            $isOwnedStop = $requestLine -eq "POST /__remocon/stop/$hostToken HTTP/1.1"
            $healthMatch = [regex]::Match($requestLine, '^GET /__remocon/health/([a-f0-9]{32}) HTTP/1\.1$')
            $keyScanMatch = [regex]::Match($requestLine, "^(GET|POST) /__remocon/keyscan/(ports|open|send|close)/$hostToken HTTP/1\.1$")
            $tapeMatch = [regex]::Match($requestLine, "^(GET|POST) /__remocon/tape/(ports|start|record|begin|stop|status)/$hostToken HTTP/1\.1$")
            $isKeyScanRequest = $keyScanMatch.Success
            $isTapeRequest = $tapeMatch.Success
            $liveMatch = [regex]::Match($requestLine, "^POST /__remocon/monitor/(devices|start|stop|pulse|volume)/$hostToken HTTP/1\.1$")
            if (-not ($isRootGet -or $isOwnedStop -or $healthMatch.Success -or $isKeyScanRequest -or $isTapeRequest -or $liveMatch.Success)) {
                Send-JsonResponse $stream 404 @{ error = 'Unknown control request.' }
                continue
            }
            if (($requestLine.StartsWith('GET ') -and $contentLength -ne 0) -or
                ($contentLength -gt 16384 -and -not ($isTapeRequest -and $tapeMatch.Groups[2].Value -eq 'start'))) {
                Send-JsonResponse $stream 413 @{ error = 'Control request body is too large.' }
                continue
            }
            if ($contentLength -gt 70000000) { Send-JsonResponse $stream 413 @{ error = 'Request body is too large.' }; continue }
            $requestBody = Read-RequestBody $stream $contentLength
            $readDeadline.Dispose()
            if ($healthMatch.Success) {
                Send-JsonResponse $stream 200 @{ service = 'remocon-health-v1'; proof = (Get-HostProof $hostToken $healthMatch.Groups[1].Value $hostRoot $PID $Port $hostProcessStarted $hostMode) }
                continue
            }
            if ($liveMatch.Success) {
                try {
                    $data = $requestBody | ConvertFrom-Json -ErrorAction Stop
                    $payload = @{}
                    foreach ($property in $data.PSObject.Properties) { $payload[$property.Name] = $property.Value }
                    Send-JsonResponse $stream 200 ($liveMonitor.Handle($liveMatch.Groups[1].Value, [string]$payload['page'], [string]$payload['lease'],
                        [string]$payload['input'], [string]$payload['output'], [double]$payload['volume'], [bool]$payload['muted'], [long]$payload['serial']))
                } catch {
                    $cause = $_.Exception; $messages = @()
                    while ($cause) { $messages += $cause.Message; $cause = $cause.InnerException }
                    Send-JsonResponse $stream 409 @{ error = ($messages -join ' -> ') }
                }
                continue
            }
            if ($isKeyScanRequest) {
                $method = $keyScanMatch.Groups[1].Value
                $action = $keyScanMatch.Groups[2].Value
                if ($action -eq 'ports' -and $method -eq 'GET') {
                    $ports = @([IO.Ports.SerialPort]::GetPortNames() | Sort-Object { if ($_ -match '^COM(\d+)$') { [int]$Matches[1] } else { [int]::MaxValue } }, { $_ })
                    Send-JsonResponse $stream 200 @{ ports = $ports }
                } elseif ($action -eq 'open' -and $method -eq 'POST') {
                    if ($keyScanPort) { Send-JsonResponse $stream 409 @{ error = "A KeyScan-Emu port is already open ($keyScanPortName). Disconnect it before choosing another port." } }
                    else {
                        $serial = $null
                        try {
                            $payload = $requestBody | ConvertFrom-Json -ErrorAction Stop
                            $requestedPort = [string]$payload.port
                            $availablePorts = @([IO.Ports.SerialPort]::GetPortNames())
                            if ([string]::IsNullOrWhiteSpace($requestedPort) -or $availablePorts -notcontains $requestedPort) { throw 'The selected COM port is no longer available. Refresh the list and choose a port again.' }
                            $serial = [IO.Ports.SerialPort]::new($requestedPort, 9600, [IO.Ports.Parity]::None, 8, [IO.Ports.StopBits]::One)
                            $serial.Handshake = [IO.Ports.Handshake]::None
                            $serial.Open()
                            $script:keyScanPort = $serial
                            $script:keyScanPortName = $requestedPort
                            Send-JsonResponse $stream 200 @{ port = $requestedPort }
                        } catch {
                            if ($serial) { try { $serial.Dispose() } catch {} }
                            Send-JsonResponse $stream 409 @{ error = $_.Exception.Message }
                        }
                    }
                } elseif ($action -eq 'send' -and $method -eq 'POST') {
                    if (-not $keyScanPort -or -not $keyScanPort.IsOpen) { Close-KeyScanPort; Send-JsonResponse $stream 409 @{ error = 'No selected KeyScan-Emu port is open.' } }
                    else {
                        try {
                            $payload = $requestBody | ConvertFrom-Json -ErrorAction Stop
                            $values = @($payload.bytes)
                            if ($values.Count -lt 1 -or $values.Count -gt 256) { throw 'Keyboard input must contain 1 to 256 bytes.' }
                            $bytes = [byte[]]@($values | ForEach-Object { $number = [int]$_; if ($number -lt 0 -or $number -gt 255) { throw 'Keyboard input contains an invalid byte.' }; $number })
                            $keyScanPort.Write($bytes, 0, $bytes.Length)
                            $keyScanPort.BaseStream.Flush()
                            Send-JsonResponse $stream 200 @{ sent = $bytes.Length }
                        } catch {
                            Close-KeyScanPort
                            Send-JsonResponse $stream 409 @{ error = "Send failed; the selected port was closed. $($_.Exception.Message)" }
                        }
                    }
                } elseif ($action -eq 'close' -and $method -eq 'POST') {
                    Close-KeyScanPort
                    Send-JsonResponse $stream 200 @{ closed = $true }
                } else {
                    Send-JsonResponse $stream 404 @{ error = 'Unknown KeyScan-Emu request.' }
                }
                continue
            } elseif ($isTapeRequest) {
                $method = $tapeMatch.Groups[1].Value
                $action = $tapeMatch.Groups[2].Value
                try {
                    if ($action -eq 'ports' -and $method -eq 'GET') {
                        $ports = @([IO.Ports.SerialPort]::GetPortNames() | Sort-Object { if ($_ -match '^COM(\d+)$') { [int]$Matches[1] } else { [int]::MaxValue } }, { $_ })
                        Send-JsonResponse $stream 200 @{ ports = $ports }
                    } elseif ($action -eq 'status' -and $method -eq 'GET') {
                        Send-JsonResponse $stream 200 (Get-TapeOperationStatus)
                    } elseif ($action -eq 'start' -and $method -eq 'POST') {
                        Send-JsonResponse $stream 200 (Start-TapePlayback $requestBody)
                    } elseif ($action -eq 'record' -and $method -eq 'POST') {
                        Send-JsonResponse $stream 200 (Start-TapeCapture $requestBody)
                    } elseif ($action -eq 'begin' -and $method -eq 'POST') {
                        Send-JsonResponse $stream 200 (Begin-TapePlayback)
                    } elseif ($action -eq 'stop' -and $method -eq 'POST') {
                        Send-JsonResponse $stream 200 (Request-TapeOperationStop)
                    } else {
                        Send-JsonResponse $stream 404 @{ error = 'Unknown TAPE request.' }
                    }
                } catch {
                    Send-JsonResponse $stream 409 @{ error = $_.Exception.Message }
                }
                continue
            } elseif ($isOwnedStop) {
                if ($liveMonitor) { $liveMonitor.Dispose() }
                if ($movieWorker) { $movieWorker.Dispose() }
                Close-KeyScanPort
                try {
                    $tapeState = Get-TapeOperationStatus
                    if ($tapeState.state -in @('Preparing','Ready','Playing','Starting','Recording')) {
                        Request-TapeOperationStop | Out-Null
                        if ($tapePlayback -and -not $tapePlayback.Process.HasExited) { [void]$tapePlayback.Process.WaitForExit(35000) }
                        if ($tapeCapture -and -not $tapeCapture.Process.HasExited) { [void]$tapeCapture.Process.WaitForExit(35000) }
                    }
                } catch {}
                $bytes = [byte[]]::new(0)
                $nl = [Environment]::NewLine
                $header = "HTTP/1.1 204 No Content$($nl)Connection: close$nl$nl"
                $running = $false
            } elseif ($isRootGet) {
                # A new/reloaded page must not autoplay while a prior witness still owns rendering.
                $monitorPage = [guid]::NewGuid().ToString('N')
                $liveMonitor.NewPage($monitorPage)
                $scripts = [IO.File]::ReadAllText((Join-Path $root 'Movie.js')) + "`n" + [IO.File]::ReadAllText((Join-Path $root 'NativeMonitor.js')) + "`n" + [IO.File]::ReadAllText((Join-Path $root 'NativePlayback.js'))
                $page = [IO.File]::ReadAllText($indexPath, [Text.UTF8Encoding]::new($false)).Replace('__REMOCON_HOST_TOKEN__', $hostToken).Replace('__REMOCON_MONITOR_PAGE__', $monitorPage).Replace('__REMOCON_MOVIE_ORIGIN__', $movieWorker.BaseUrl).Replace('__REMOCON_MOVIE_SCRIPT__', $scripts)
                $bytes = [Text.Encoding]::UTF8.GetBytes($page)
                $header = "HTTP/1.1 200 OK`r`nContent-Type: text/html; charset=utf-8`r`nCache-Control: no-store`r`nContent-Length: $($bytes.Length)`r`nConnection: close`r`n`r`n"
            } else {
                $bytes = [Text.Encoding]::UTF8.GetBytes('Not found')
                $header = "HTTP/1.1 404 Not Found`r`nContent-Type: text/plain; charset=utf-8`r`nContent-Length: $($bytes.Length)`r`nConnection: close`r`n`r`n"
            }
            $headBytes = [Text.Encoding]::ASCII.GetBytes($header)
            $stream.Write($headBytes, 0, $headBytes.Length)
            $stream.Write($bytes, 0, $bytes.Length)
        } catch {
        } finally {
            $readDeadline.Dispose()
            $client.Dispose()
        }
    }
} finally {
    if ($liveMonitor) { try { $liveMonitor.Dispose() } catch { Write-Warning $_.Exception.Message } }
    Close-KeyScanPort
    if ($movieWorker) { $movieWorker.Dispose() }
    try { if (($tapePlayback -and -not $tapePlayback.Process.HasExited) -or ($tapeCapture -and -not $tapeCapture.Process.HasExited)) { Request-TapeOperationStop | Out-Null; if ($tapePlayback -and -not $tapePlayback.Process.HasExited) { [void]$tapePlayback.Process.WaitForExit(35000) }; if ($tapeCapture -and -not $tapeCapture.Process.HasExited) { [void]$tapeCapture.Process.WaitForExit(35000) } } } catch {}
    if ($tapePlayback -and $tapePlayback.Process.HasExited) { Remove-TapePlaybackFiles $tapePlayback }
    if ($tapeCapture -and $tapeCapture.Process.HasExited) { Remove-TapePlaybackFiles $tapeCapture }
    $listener.Stop()
    Remove-HostState
}
} finally { Release-StartupGate }
