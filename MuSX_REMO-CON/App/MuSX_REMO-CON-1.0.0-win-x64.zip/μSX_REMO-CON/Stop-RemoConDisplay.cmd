@echo off
setlocal
rem The stop script contacts only the token-owned MuSX REMO-CON loopback host.
powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Stop-RemoConDisplay.ps1" -ShowStatus
endlocal
exit /b
