[CmdletBinding()]
param([switch]$ShowStatus)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSCommandPath
$statePath = Join-Path (Join-Path $root 'state') 'display-host.json'

function Show-StopStatus([string]$Message, [string]$Icon = 'Information') {
    if ($ShowStatus) {
        try {
            Add-Type -AssemblyName PresentationFramework
            [void][System.Windows.MessageBox]::Show($Message, 'MuSX REMO-CON', 'OK', $Icon)
            return
        } catch {}
    }
    Write-Host $Message
}

if (-not (Test-Path -LiteralPath $statePath -PathType Leaf)) {
    Show-StopStatus 'MuSX REMO-CON is not running.'
    exit 0
}

try {
    $state = Get-Content -LiteralPath $statePath -Raw -Encoding utf8 | ConvertFrom-Json -ErrorAction Stop
    if ($state.v -ne 1 -or [int]$state.port -lt 1024 -or [int]$state.port -gt 65535 -or
        [string]$state.token -notmatch '^[a-f0-9]{32}$') {
        throw 'The project-local host record is not valid.'
    }
    $probe = [Net.Sockets.TcpClient]::new()
    try {
        $probe.Connect([Net.IPAddress]::Loopback, [int]$state.port)
    } catch {
        Remove-Item -LiteralPath $statePath -Force -ErrorAction SilentlyContinue
        Show-StopStatus 'MuSX REMO-CON is not running.'
        exit 0
    } finally {
        $probe.Dispose()
    }
    $request = [Net.WebRequest]::Create("http://127.0.0.1:$([int]$state.port)/__remocon/stop/$([string]$state.token)")
    $request.Method = 'POST'
    $request.Timeout = 3000
    $response = $request.GetResponse()
    try {
        if ([int]$response.StatusCode -ne 204) { throw "Unexpected stop response: $([int]$response.StatusCode)." }
    } finally {
        $response.Close()
    }
    Remove-Item -LiteralPath $statePath -Force -ErrorAction SilentlyContinue
    Show-StopStatus 'MuSX REMO-CON background host stopped.'
} catch {
    $connectionRefused = $false
    $currentError = $_.Exception
    while ($currentError) {
        if ($currentError -is [Net.WebException] -and $currentError.Status -eq [Net.WebExceptionStatus]::ConnectFailure) {
            $connectionRefused = $true
            break
        }
        $currentError = $currentError.InnerException
    }
    if ($connectionRefused) {
        Remove-Item -LiteralPath $statePath -Force -ErrorAction SilentlyContinue
        Show-StopStatus 'MuSX REMO-CON is not running.'
        exit 0
    }
    Show-StopStatus "MuSX REMO-CON was not stopped. $($_.Exception.Message)" 'Error'
    exit 1
}
