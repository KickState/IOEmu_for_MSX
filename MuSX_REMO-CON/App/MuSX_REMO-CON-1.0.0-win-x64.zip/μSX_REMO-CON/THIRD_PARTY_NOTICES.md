# Third-party components

KickState-authored material in this package is governed by [LICENSE](LICENSE). Bundled third-party components are governed by their respective licenses and notices. Microsoft and other component authors do not endorse this product by supplying these components.

## Microsoft WebView2 SDK

The package redistributes these files from Microsoft.Web.WebView2 SDK **1.0.4191.47**:

- Microsoft.Web.WebView2.Core.dll
- Microsoft.Web.WebView2.WinForms.dll
- WebView2Loader.dll (Windows x64)

The complete original [SDK license](notices/WebView2-LICENSE.txt) and [SDK third-party notice](notices/WebView2-NOTICE.txt) accompany them unchanged. The latter includes ANTLR/StringTemplate notices supplied by Microsoft; it is preserved as the SDK notice, not presented as an independently derived list of separate files in this package.

Microsoft Edge WebView2 **Evergreen Runtime is not bundled**. It is supplied and installed separately by Microsoft. See the [official download page](https://developer.microsoft.com/en-us/microsoft-edge/webview2/).

## CAS-IF Tape Backup console helpers

`tape_cmd/playback.exe` and `tape_cmd/capture.exe` provide TAPE playback/capture. The original [KickState terms](tape_cmd/LICENSE) and [upstream third-party notice](tape_cmd/THIRD_PARTY_NOTICES.txt) are preserved unchanged.

These are PyInstaller one-file console applications. Their embedded archives contain CPython 3.12, Python extension modules and standard-library modules, pyserial, PyInstaller runtime/bootstrap code, OpenSSL/libcrypto, libffi and VCRUNTIME140.dll. Separate Python installation is not required. They extract runtime files temporarily when executed.

The helpers use CPython 3.12.14, PyInstaller 6.22.2, pyserial 3.5, OpenSSL 3.5.8, libffi and Microsoft-signed VCRUNTIME140.dll 14.44.35211.0. Their respective terms are the Python Software Foundation License, GPL-2.0-or-later with the PyInstaller bootloader exception, BSD 3-Clause, Apache-2.0, MIT and the applicable Microsoft runtime terms. The original upstream notice accompanies this helper subset unchanged; each component remains governed by its own terms.

The upstream notice also discusses Tcl/Tk and AtomU firmware in the broader CAS-IF Tape Backup distribution. These two console helpers do not bundle its Tk GUI or firmware images. The REMO-CON ZIP does not install or update interface firmware.

## Runtime environment and source files

Windows, Microsoft Edge and the WebView2 Evergreen Runtime are external requirements, not copied into this package. The JavaScript and PowerShell files and the two C# worker sources are application runtime inputs, not bundled development SDKs. The C# workers are compiled by the host at startup. No external JavaScript framework or ESERAMair utility executable is bundled.

## 日本語

同梱の WebView2 SDK ファイルには Microsoft のライセンス・通知の原文を添付しています。Evergreen Runtime 自体は同梱せず、別途 Microsoft から提供されます。

TAPE の二つのコンソールヘルパーには CAS-IF Tape Backup の利用条件と第三者通知を原文のまま添付しています。上流の通知にはより広い配布物の GUI・ファームウェアについての記述もありますが、本パッケージはそれらを同梱しません。この概要は各コンポーネントのライセンス原文や再配布許諾を置き換えるものではありません。
